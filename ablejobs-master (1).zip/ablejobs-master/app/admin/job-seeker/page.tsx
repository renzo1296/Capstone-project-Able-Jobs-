import pool from "@/app/lib/db";
import { UserTypeEnum } from "@/app/types/common";
import styles from "./page.module.css";
import Image from "next/image";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPen } from "@fortawesome/free-solid-svg-icons";
import { GetFilePublicLink, getUserDir, ListBucketFiles } from "@/app/lib/supabase";
import Link from "next/link";
import DeleteModal from "./[id]/edit/components/DeleteModal";

export default async function Page() {
    const query = `
    SELECT * 
        FROM user_ u
    JOIN job_seeker_ js ON u.id = js.user_id
    WHERE u.user_type = $1
    `;
    const users = (await pool.query(query, [UserTypeEnum.Values.job_seeker])).rows;

    const getUserProfilePicSrc = async (username: string) => {
        const userDir = getUserDir(username);
        const currentUserFiles = await ListBucketFiles(userDir);
        const existingProfilePic = currentUserFiles.find((f) =>
            f.name.startsWith("profile_pic")
        );
        return existingProfilePic
            ? GetFilePublicLink(`${userDir}/${existingProfilePic.name}`)
            : "/default_pic.jpg";
    };

    return (
        <main className={styles.main}>
            <h1 className={styles.h1}>Job Seekers</h1>

            <div className={styles.container}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>Profile</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {await Promise.all(
                            users.map(async (user) => {
                                const profilePicSrc = await getUserProfilePicSrc(user.username);
                                return (
                                    <tr key={user.id}>
                                        <td data-label="Profile">
                                            <div className={styles.profileWrapper}>
                                            <Image
                                            src={profilePicSrc}
                                            alt="profile"
                                            fill
                                            className={styles.profilePic}
                                            />
                                            </div>
                                        </td>
                                        <td data-label="Name">
                                            {user.firstname} {user.lastname}
                                        </td>
                                        <td data-label="Username">{user.username}</td>
                                        <td data-label="Email">{user.email}</td>
                                        <td data-label="Actions">
                                            <Link href={`/admin/job-seeker/${user.id}/edit`} target="_blank">
                                                <FontAwesomeIcon icon={faPen} className={styles.actionIcon} />
                                            </Link>
                                            <DeleteModal userId={user.id} />
                                        </td>
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                </table>
            </div>
        </main>
    );
}
