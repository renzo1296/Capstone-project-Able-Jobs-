'use client'

import { deleteAccount } from "@/app/profile/action/delete"
import { useState } from "react"
import { createPortal } from "react-dom"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash } from '@fortawesome/free-solid-svg-icons';
import styles from '@/app/admin/job-seeker/page.module.css';
import ConfirmationModal from "@/app/components/ConfirmationModal"

type DeleteModalProps = {
    userId: number
}

export default function DeleteModal ({ userId } : DeleteModalProps) {
    const [isDeleting, setIsDeleting] = useState(false)
    return (
        <>
            {
                isDeleting && 
                createPortal(
                    <ConfirmationModal 
                        onNo={() => setIsDeleting(false)}
                        onYes={() => deleteAccount(userId)}
                    />, globalThis.document.body)
            }
            <FontAwesomeIcon onClick={() => setIsDeleting(true)} icon={faTrash} className={`${styles.actionIcon} ${styles.deleteIcon}`} />
        </>
    )
}
