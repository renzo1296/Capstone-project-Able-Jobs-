import pool, { DisabilityTypeDb, getDisabilityOptions } from "@/app/lib/db";
import styles from './page.module.css';
import { GetFilePublicLink, getUserDir, ListBucketFiles } from '@/app/lib/supabase';
import UpdateForm from "@/app/profile/components/UpdateForm";
import { User } from "@/app/types/common";
import { WorkExpItemSchema } from "@/app/components/definitions";

export default async function EditJobSeekerPage({ params }: { params: Promise<{ id: string }> }) {
    const { id } = await params;
    const query = `
        SELECT u.*, js.firstname, js.lastname, js.sex, js.birthdate, js.address,
               js.phone_number, js.pwd_id_number, js.senior_id_number,
               js.sss, js.tin, js.philhealth, js.education
        FROM user_ u
        JOIN job_seeker_ js ON u.id = js.user_id
        WHERE u.id = $1
    `;
    const profileData = (await pool.query<User>(query, [id])).rows[0];

    // Fetch work experiences separately
    const workExpQuery = `
        SELECT id, company AS company, position AS position, from_date AS "from", 
               to_date AS "to", is_present
        FROM work_exp_
        WHERE user_id = $1
        ORDER BY from_date DESC
    `;
    const workExpRes = await pool.query<WorkExpItemSchema>(workExpQuery, [id]);
    profileData.work_exp = workExpRes.rows; // attach to User object

    // Fetch disabilities
    const disabilityOptions = await getDisabilityOptions();
    const disabilityQuery = `
        SELECT d.type, d.name
        FROM job_seeker_disability_type_ jsd
        JOIN disability_type_ d ON d.type = jsd.disability_type
        WHERE jsd.user_id = $1
        ORDER BY d.type ASC
    `;

    const disabilityRes = await pool.query<DisabilityTypeDb>(
        disabilityQuery,
        [id]
    );

    profileData.disabilities = disabilityRes.rows.map(r => ({
        value: r.type,
        label: r.name
    }));

    // profile pic files
    const userDir = getUserDir(profileData.username);
    const currentUserFiles = await ListBucketFiles(userDir);

    const profilePicUrlSrc = getFileUrlSrc('profile_pic', '/default_pic.jpg');
    const pwdIdPicUrlSrc = getFileUrlSrc('pwd_id_pic');
    const resumeFileUrlSrc = getFileUrlSrc('resume_file');
    const governmentIssuedIdPicUrlSrc = getFileUrlSrc('government_issued_id_pic');
    const nbiClearanceUrlSrc = getFileUrlSrc('nbi_clearance');
    const torUrlSrc = getFileUrlSrc('tor');

    function getFileUrlSrc(fileNamePrefix: string, defaultFileUrlSrc='') {
        const existingFile = currentUserFiles.find(file => file.name.startsWith(fileNamePrefix));
        return existingFile ? GetFilePublicLink(`${userDir}/${existingFile.name}`) : defaultFileUrlSrc;
    }

    return (
        <main className={styles.profile_main_section}>
            <h1>Editing: {profileData.username}</h1>
            <br />
            <UpdateForm
                profilePicUrlSrc={profilePicUrlSrc} 
                pwdIdPicUrlSrc={pwdIdPicUrlSrc}
                resumeFileUrlSrc={resumeFileUrlSrc}
                governmentIssuedIdPicUrlSrc={governmentIssuedIdPicUrlSrc}
                nbiClearanceUrlSrc={nbiClearanceUrlSrc}
                torUrlSrc={torUrlSrc}
                profileData={ profileData } 
                disabilityOptions={disabilityOptions}
                isAdmin 
            />
        </main>
    );
}

