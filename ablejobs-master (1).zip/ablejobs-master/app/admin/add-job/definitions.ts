import { makeCitySchema, makeDisabilitySchema } from "@/app/job-search/definitions";
import { EducationEnum, JobTypeEnum } from "@/app/types/common";
import { z } from "zod";

export type AddJobState = {
    errors?: AddJobStateErrors
    message?: string
    isErrorMessage?: boolean
} | undefined

export type AddJobStateErrors = {
    company_name?: string[]
    job_title?: string[]
    job_type?: string[]
    job_details?: string[]
    location?: string[]
    monthly_salary?: string[]
    disabilities?: string[]
    city?: string[]
    education?: string[]
}

export async function makeAddJobFormSchema() {
    return z.object({
        company_name: z
            .string()
            .min(1, { message: 'Company name is required.' })
            .max(50, { message: 'Company name must be at most 50 characters long.'})
            .trim(),
        job_title: z
            .string()
            .min(1, { message: 'Job title is required.'})
            .max(50, { message: 'Job title must be at most 50 characters long.'})
            .trim(),
        job_type: JobTypeEnum,
        job_details: z
            .string()
            .max(1000, {message: 'Job details must be at most 1000 characters long.'})
            .trim(),
        location: z
            .string()
            .min(1, { message: 'Location is required.'})
            .max(100, { message: 'Location must be at most 100 characters long.'})
            .trim(),
        monthly_salary: z
            .string()
            .regex(/^\d+(\.\d{1,2})?$/, {
                message: "Monthly salary must be a valid number with up to 2 decimal places.",
            })
            .refine((val) => parseFloat(val) >= 0, {
                message: "Monthly salary must be a non-negative number.",
            }),
        disabilities: z.array(await makeDisabilitySchema())
            .transform(disabilities => disabilities.filter(disability => disability !== '')),
        city: await makeCitySchema(false),
        education: EducationEnum 
    });
}

export type AddJobFormSchema = z.infer<ReturnType<typeof makeAddJobFormSchema> extends Promise<infer S> ? S : never>;
