'use server'

import pool from "@/app/lib/db"
import { AddJobState, makeAddJobFormSchema } from "../definitions"
import AddJobNotifEmail, { AddJobNotifEmailProps } from "@/app/job/[id]/components/AddJobNotifEmail";
import { SendEmail } from "@/app/lib/brevo";
import { getSession } from "@/app/utils/server/auth";
import { UserTypeEnum } from "@/app/types/common";

export async function addJob(prevState: AddJobState, formData: FormData): Promise<AddJobState> {
    const session = await getSession();
    if (!session || session.user_type !== UserTypeEnum.Values.admin)
        return prevState;

    const entries = {
        'company_name': formData.get('company_name'),
        'job_title': formData.get('job_title'),
        'job_details': formData.get('job_details'),
        'location': formData.get('location'),
        'monthly_salary': formData.get('monthly_salary'),
        'job_type': formData.get('job_type'),
        'city': formData.get('city'),
        'disabilities': formData.getAll('disabilities'),
        'education': formData.get('education'),
    };
    console.log("da data i got add job:", entries);

    const addJobFormSchema = await makeAddJobFormSchema();
    const validatedFields = addJobFormSchema.safeParse(entries);
    if (!validatedFields.success) {
        console.log(validatedFields.error.flatten().fieldErrors)
        return {
            errors: validatedFields.error.flatten().fieldErrors,
        }
    }

    try {
        const query = `
            WITH new_job AS (
            INSERT INTO job_ (
                company_name, job_title, job_type, job_details,
                city_name, location, monthly_salary, education, date_posted
            )
            VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9
            )
            RETURNING id
            )
            INSERT INTO job_disability_type_ (job_id, disability_type)
            VALUES ` 
            + validatedFields.data.disabilities
                .map(d => `((SELECT id FROM new_job), '${d}')`)
                .join(",\n") 
            + ';';
        
        const values = [
            validatedFields.data.company_name,
            validatedFields.data.job_title,
            validatedFields.data.job_type,
            validatedFields.data.job_details,
            validatedFields.data.city,
            validatedFields.data.location,
            validatedFields.data.monthly_salary,
            validatedFields.data.education,
            new Date().toISOString()
        ];
        await pool.query(query, values);
    }
    catch (error: unknown) {
        console.error('Context:', "Database insert error");
        if (error instanceof Error) {
            console.error('Caught error:', error.message);
            return {
                message: "Database insert error: " + error.message,
                isErrorMessage: true
            }
        } 
        else {
            console.error('Unknown error:', error);
            return {
                message: "Database insert unknown error: " + error,
                isErrorMessage: true
            }
        }
    }

    // notify users whose disabilities match the job
    const query = `
        SELECT DISTINCT u.email, js.firstname, js.lastname
        FROM user_ u
        JOIN job_seeker_ js ON u.id = js.user_id
        JOIN job_seeker_disability_type_ jsd ON jsd.user_id = u.id
        WHERE jsd.disability_type = ANY($1::varchar[])
    `;
    const res = await pool.query<{ email: string; firstname: string; lastname: string }>(
        query,
        [validatedFields.data.disabilities]
    );
    const users = res.rows;

    for (const user of users) {
        const props: AddJobNotifEmailProps = {
            first_name: user.firstname,
            company_name: validatedFields.data.company_name,
            job_title: validatedFields.data.job_title,
            job_type: validatedFields.data.job_type,
            job_details: validatedFields.data.job_details,
            location: validatedFields.data.location,
            monthly_salary: `PHP ${validatedFields.data.monthly_salary}`,
            disabilities: validatedFields.data.disabilities.join(", "),
            city: validatedFields.data.city,
            education: validatedFields.data.education
        };

        const ReactDOMServer = await import("react-dom/server");
        const html = ReactDOMServer.renderToStaticMarkup(
            <AddJobNotifEmail {...props} />
        );

        // don't await, fire and forget
        SendEmail(
            `New Job Posted – ${validatedFields.data.job_title}`,
            html,
            `${user.firstname} ${user.lastname}`,
            user.email
        );
    }

    return {
        message: "Job added!"
    }
}

