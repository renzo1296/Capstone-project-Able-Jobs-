'use client'

import { useTheme } from '@/app/context/ThemeContext'
import Select from "react-select"
import { useActionState, startTransition } from "react"
import { addJob } from "../action/addjob"
import { educationOptions, jobTypeOptions, MultiSelectOption } from "@/app/types/common"
import styles from "./AddJobForm.module.css"
import { AddJobState } from "../definitions"
import { getSingleSelectStyles, getMultiSelectStyles } from '@/app/types/styles'

interface AddJobFormProps {
    cityOptions: MultiSelectOption[]
    disabilityOptions: MultiSelectOption[]
}

export default function AddJobForm({ cityOptions, disabilityOptions }: AddJobFormProps) {
    const { theme } = useTheme()
    const isDarkMode = theme === 'dark'
    const singleSelectStyles = getSingleSelectStyles(isDarkMode);
    const multiSelectStyles = getMultiSelectStyles(isDarkMode);

    const [addJobState, addJobAction, pending] = useActionState(
        (prevLoginState: AddJobState, formData: FormData) => 
        addJob(prevLoginState, formData), undefined);

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        startTransition(() => addJobAction(formData))
    };
    return (
        <form className={styles.form} onSubmit={handleSubmit}>
            <label htmlFor="company_name">Company Name</label><br />
            { addJobState?.errors?.company_name && <p className={styles.error_msg}>{ addJobState.errors.company_name }</p> }
            <input className={styles.form_input} type="text" id="company_name" name="company_name" />

            <label htmlFor="job_title">Job Title</label><br />
            { addJobState?.errors?.job_title && <p className={styles.error_msg}>{ addJobState.errors.job_title }</p> }
            <input className={styles.form_input} type="text" id="job_title" name="job_title" />

            <label htmlFor="job_type">Job Type</label><br />
            { addJobState?.errors?.job_type && <p className={styles.error_msg}>{ addJobState.errors.job_type }</p> }
            <div className={styles.select_container}>
                <Select
                    options={jobTypeOptions}
                    styles={singleSelectStyles}
                    id="job_type"
                    name="job_type"
                    placeholder="Job Type"
                />
            </div>

            <label htmlFor="job_details">Job Details</label><br />
            { addJobState?.errors?.job_details && <p className={styles.error_msg}>{ addJobState.errors.job_details }</p> }
            <input className={styles.form_input} type="text" id="job_details" name="job_details" />

            <label htmlFor="Location">Location</label><br />
            { addJobState?.errors?.location && <p className={styles.error_msg}>{ addJobState.errors.location }</p> }
            <input className={styles.form_input} type="text" id="location" name="location" />

            <label htmlFor="monthly_salary">Monthly Salary</label><br />
            { addJobState?.errors?.monthly_salary && <p className={styles.error_msg}>{ addJobState.errors.monthly_salary }</p> }
            <input className={styles.form_input} type="number" step="0.01" min="0" id="monthly_salary" name="monthly_salary" />

            <label htmlFor="disabilities">Disabilities</label><br />
            { addJobState?.errors?.disabilities && <p className={styles.error_msg}>{ addJobState.errors.disabilities }</p> }
            <div className={styles.select_container}>
                <Select
                    isMulti
                    options={disabilityOptions}
                    id="disabilities"
                    name="disabilities"
                    placeholder={"Disability Type"}
                    closeMenuOnSelect={false}
                    styles={multiSelectStyles}
                />
            </div>

            <label htmlFor="city">City</label><br />
            { addJobState?.errors?.city && <p className={styles.error_msg}>{ addJobState.errors.city }</p> }
            <div className={styles.select_container}>
                <Select
                    options={cityOptions}
                    id="city"
                    name="city"
                    placeholder={"City"}
                    styles={singleSelectStyles}
                />
            </div>

            <label htmlFor="education">Education</label><br />
            { addJobState?.errors?.education && <p className={styles.error_msg}>{ addJobState.errors.education }</p> }
            <div className={styles.select_container}>
                <Select
                    options={educationOptions}
                    id="education"
                    name="education"
                    placeholder={"Qualification"}
                    styles={singleSelectStyles}
                />
            </div>

            <button className={styles.form_btn} disabled={pending} type="submit">
                {pending ? 'Adding...' : 'Add Job'}
            </button>
            
            {addJobState?.message && (
                <p className={addJobState.isErrorMessage ? styles.error_flash : styles.success_flash}>
                    {addJobState?.message}
                </p>
            )}
        </form>
    )
}

