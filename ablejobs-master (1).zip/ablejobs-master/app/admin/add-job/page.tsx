import { getCityOptions, getDisabilityOptions } from "@/app/lib/db"
import AddJobForm from "./components/AddJobForm"
import styles from "./page.module.css"

export default async function Page() {
    const cityOptions = await getCityOptions();
    const disabilityOptions = await getDisabilityOptions();
    return (
        <main className={styles.main}>
            <h1 className={styles.h1}>Add New Job</h1>
            <div className={styles.form_container}>
                <AddJobForm cityOptions={cityOptions} disabilityOptions={disabilityOptions}/>
            </div>
        </main>
    )
}
