import pool from "@/app/lib/db";
import { UserTypeEnum } from "@/app/types/common";
import styles from "./page.module.css";

export default async function Page() {
    const usersCnt = (await pool.query(`SELECT * FROM user_ WHERE user_type = $1`, [UserTypeEnum.Values.job_seeker])).rowCount;
    const jobsCnt = (await pool.query(`SELECT * FROM job_`)).rowCount;

    return (
        <main className={styles.main}>
            <h1 className={styles.h1}>Dashboard</h1>
            <div className={styles.statsGrid}>
                <div className={styles.card}>
                    <h2>No. of users</h2>
                    <p className={styles.count}>{usersCnt}</p>
                </div>
                <div className={styles.card}>
                    <h2>No. of job postings</h2>
                    <p className={styles.count}>{jobsCnt}</p>
                </div>
            </div>
        </main>
    );
}

