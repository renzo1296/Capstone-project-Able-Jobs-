'use server'

import { keyToName } from "@/app/utils/stringHelpers";
import { AddCityState, makeAddCityFormSchema } from "../definitions";
import pool from "@/app/lib/db";
import { getSession } from "@/app/utils/server/auth";
import { UserTypeEnum } from "@/app/types/common";

export async function addCity(prevState: AddCityState, formData: FormData): Promise<AddCityState> {
    const session = await getSession();
    if (session?.user_type !== UserTypeEnum.Values.admin) {
        return {
            message: "Unauthorized",
            isErrorMessage: true
        };
    }

    const city = formData.get("city");

    const schema = await makeAddCityFormSchema();
    const validated = schema.safeParse({ city });

    if (!validated.success) {
        return { errors: validated.error.flatten().fieldErrors };
    }

    try {
        await pool.query(
            "INSERT INTO city_ (city, name) VALUES ($1, $2)",
            [validated.data.city, keyToName(validated.data.city)]
        );
    } catch (err: unknown) {
        return {
            message: err instanceof Error ? err.message : "Unknown error",
            isErrorMessage: true
        };
    }

    return { message: "City added!" };
}


