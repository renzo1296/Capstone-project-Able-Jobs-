import { getCityKeysDb } from "@/app/lib/db";
import { normalizeKey } from "@/app/utils/stringHelpers";
import { z } from "zod";

export type AddCityState = {
    errors?: { city?: string[] }
    message?: string
    isErrorMessage?: boolean
} | undefined

export async function makeAddCitySchema() {
    const cityRows = await getCityKeysDb();
    const cityKeys = cityRows.map(row => row.city);
    return z.string().refine(
        val => !cityKeys.includes(val),
        { message: "City already exists" }
    );
}

export async function makeAddCityFormSchema() {
    return z.object({
        city: z
            .string()
            .trim()
            .min(1, { message: "City is required." })
            .max(50, { message: "City must be at most 50 characters long." })
            .transform(val => normalizeKey(val))
            .pipe(await makeAddCitySchema())
    });
}


