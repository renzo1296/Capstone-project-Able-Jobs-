'use server'

import AddCityForm from "./components/AddCityForm";
import styles from "../add-job/page.module.css";

export default async function Page() {
    return (
        <main className={styles.main}>
            <h1 className={styles.h1}>Add New City</h1>
            <div className={styles.form_container}>
                <AddCityForm />
            </div>
        </main>
    );
}
