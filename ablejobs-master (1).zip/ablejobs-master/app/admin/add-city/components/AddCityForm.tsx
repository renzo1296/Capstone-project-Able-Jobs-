'use client'

import { useTheme } from '@/app/context/ThemeContext'
import { useActionState, startTransition } from "react";
import { AddCityState } from "../definitions";
import { addCity } from "../action/addCity";
import styles from "../../add-job/components/AddJobForm.module.css";

export default function AddCityForm() {
    const { theme } = useTheme();
    const isDarkMode = theme === 'dark';

    const [state, action, pending] = useActionState(
        (prev: AddCityState, formData: FormData) => addCity(prev, formData),
        undefined
    );

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        startTransition(() => action(formData));
    };

    return (
        <form
            className={styles.form}
            data-theme={isDarkMode ? 'dark' : 'light'}
            onSubmit={handleSubmit}
        >
            <label htmlFor="city">New City</label>
            {state?.errors?.city && <p className={styles.error_msg}>{state.errors.city}</p>}
            <input className={styles.form_input} type="text" id="city" name="city" />

            <button className={styles.form_btn} type="submit" disabled={pending}>
                {pending ? "Adding..." : "Add City"}
            </button>

            {state?.message && (
                <p className={state.isErrorMessage ? styles.error_flash : styles.success_flash}>
                    {state.message}
                </p>
            )}
        </form>
    );
}

