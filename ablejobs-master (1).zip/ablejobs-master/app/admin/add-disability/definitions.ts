import { getDisabilityTypesDb } from "@/app/lib/db";
import { normalizeKey } from "@/app/utils/stringHelpers";
import { z } from "zod";

export type AddDisabilityState = {
    errors?: { disability?: string[] }
    message?: string
    isErrorMessage?: boolean
} | undefined

export async function makeAddDisabilitySchema() {
    const disabilityRows = await getDisabilityTypesDb();
    const disabilityTypes = disabilityRows.map(row => row.type);
    return z.string().refine(
        val => !disabilityTypes.includes(val),
        { message: "Disability already exists" }
    );
}

export async function makeAddDisabilityFormSchema() {
    return z.object({
        disability: z
            .string()
            .trim()
            .min(1, { message: "Disability is required." })
            .max(50, { message: "Disability must be at most 50 characters long." })
            .transform(val => normalizeKey(val))
            .pipe(await makeAddDisabilitySchema())
    });
}

