'use server'

import AddDisabilityForm from "./components/AddDisabilityForm";
import styles from "../add-job/page.module.css";

export default async function Page() {
    return (
        <main className={styles.main}>
            <h1 className={styles.h1}>Add New Disability</h1>
            <div className={styles.form_container}>
                <AddDisabilityForm />
            </div>
        </main>
    );
}

