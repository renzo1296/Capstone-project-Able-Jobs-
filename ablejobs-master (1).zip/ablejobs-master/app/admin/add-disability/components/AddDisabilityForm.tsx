'use client'

import { useTheme } from '@/app/context/ThemeContext'
import { useActionState, startTransition } from "react";
import { AddDisabilityState } from "../definitions";
import { addDisability } from "../action/addDisability";
import styles from "../../add-job/components/AddJobForm.module.css";

export default function AddDisabilityForm() {
    const { theme } = useTheme();
    const isDarkMode = theme === 'dark';

    const [state, action, pending] = useActionState(
        (prev: AddDisabilityState, formData: FormData) => addDisability(prev, formData),
        undefined
    );

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        startTransition(() => action(formData));
    };

    return (
        <form
            className={styles.form}
            data-theme={isDarkMode ? 'dark' : 'light'}
            onSubmit={handleSubmit}
        >
            <label htmlFor="disability">New Disability</label>
            {state?.errors?.disability && <p className={styles.error_msg}>{state.errors.disability}</p>}
            <input className={styles.form_input} type="text" id="disability" name="disability" />

            <button className={styles.form_btn} type="submit" disabled={pending}>
                {pending ? "Adding..." : "Add Disability"}
            </button>

            {state?.message && (
                <p className={state.isErrorMessage ? styles.error_flash : styles.success_flash}>
                    {state.message}
                </p>
            )}
        </form>
    );
}

