'use server'

import { keyToName } from "@/app/utils/stringHelpers";
import { AddDisabilityState, makeAddDisabilityFormSchema } from "../definitions";
import pool from "@/app/lib/db";
import { getSession } from "@/app/utils/server/auth";
import { UserTypeEnum } from "@/app/types/common";

export async function addDisability(prevState: AddDisabilityState, formData: FormData): Promise<AddDisabilityState> {
    const session = await getSession();
    if (session?.user_type !== UserTypeEnum.Values.admin) {
        return {
            message: "Unauthorized",
            isErrorMessage: true
        };
    }

    const disability = formData.get("disability");

    const schema = await makeAddDisabilityFormSchema();
    const validated = schema.safeParse({ disability });

    if (!validated.success) {
        return { errors: validated.error.flatten().fieldErrors };
    }

    try {
        await pool.query(
            "INSERT INTO disability_type_ (type, name) VALUES ($1, $2)",
            [validated.data.disability, keyToName(validated.data.disability)]
        );
    } catch (err: unknown) {
        return {
            message: err instanceof Error ? err.message : "Unknown error",
            isErrorMessage: true
        };
    }

    return { message: "Disability added!" };
}

