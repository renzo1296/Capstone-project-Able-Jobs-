import * as Brevo from '@getbrevo/brevo'

const apiInstance = new Brevo.TransactionalEmailsApi()
apiInstance.setApiKey(
    Brevo.TransactionalEmailsApiApiKeys.apiKey,
    process.env.BREVO_API_KEY!
)

export async function SendEmail(subject: string, htmlBodyContent: string, sendToUsername: string, sendToEmail: string) {
    const sendSmtpEmail: Brevo.SendSmtpEmail = {
        subject: subject,
        htmlContent: `
            <html>
                <head></head>
                <body>
                    ${htmlBodyContent}
                </body>
            </html>
        `,
        sender: {
            name: 'AbleJobs Team',
            email: 'ablejobs-noreply@ablejobs.xyz',
        },
        to:
        [
            {
                email: sendToEmail,
                name: sendToUsername,
            },
        ],
    }
    try {
        const res = await apiInstance.sendTransacEmail(sendSmtpEmail)
        console.log('Email Sent:', res)
    } 
    catch (err) {
        console.error('Error while sending email:', err)
    }
}
