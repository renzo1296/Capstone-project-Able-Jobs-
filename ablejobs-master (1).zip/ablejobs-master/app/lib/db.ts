import { Pool } from "pg";
import { MultiSelectOption } from "../types/common";

const ssl = process.env.SSL ? (
{
    rejectUnauthorized: true,
    ca: process.env.SSL === 'true' ? undefined : Buffer.from(process.env.SSL, 'base64').toString('utf-8')
}) : undefined;

const pool = new Pool({
    ssl
}); 
export default pool;

export interface DisabilityTypeDb { 
    type: string; 
    name: string;
}
export interface CityTypeDb { 
    city: string; 
    name: string;
}

export async function getDisabilityTypesDb(): Promise<DisabilityTypeDb[]> {
    const result = await pool.query<DisabilityTypeDb>(
        "SELECT type, name FROM disability_type_ ORDER BY type ASC"
    );
    return result.rows;
}

export async function getDisabilityOptions(): Promise<MultiSelectOption[]> {
    const dbRows = await getDisabilityTypesDb();
    return dbRows.map(row => ({
        value: row.type,
        label: row.name
    }));
}

export async function getCityKeysDb(): Promise<CityTypeDb[]> {
    const result = await pool.query<CityTypeDb>(
        "SELECT city, name FROM city_ ORDER BY city ASC"
    );
    return result.rows;
}

export async function getCityOptions(): Promise<MultiSelectOption[]> {
    const dbRows = await getCityKeysDb();
    return dbRows.map(row => ({
        value: row.city,
        label: row.name
    }));
}
