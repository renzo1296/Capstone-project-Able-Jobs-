import { createClient } from '@supabase/supabase-js'
import path from 'path'

export const supabase = createClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_ANON_KEY!
);

export const BUCKET_NAME = process.env.SUPABASE_BUCKET_NAME!;
export const getUserDir = (username: string) => `users/${username}`;

/**
 * Retrieves metadata about the bucket named `bucketName`.
 *
 * - Throws an error if the bucket specified by `bucketName` does not exist.
 *
 * @param bucketName - The name of the bucket to retrieve.
 * @returns The bucket metadata if found; otherwise `undefined`.
 */
export async function GetBucket(bucketName: string) {
    const { data, error } = await supabase.storage.getBucket(bucketName);

    if (error)
        console.log(`${error.name}: ${error.message}`);

    return data;
}

/**
 * Creates a new bucket with the given `bucketName`.
 *
 * - Fails with an error if a bucket named `bucketName` already exists (StorageAPIError: The resource already exists).
 *
 * @param bucketName - The name of the bucket to create.
 * @returns `true` if the bucket was created successfully, otherwise `false`.
 */
export async function CreateBucket(bucketName: string) {
    const { error } = await supabase
        .storage
        .createBucket(bucketName);

    if (error) {
        console.error(`${error.name}: ${error.message}`);
        return false;
    }

    return true;
}

 /**
 * Lists files and folders within the specified `folderPath` in the storage bucket.
 *
 * - If the folder specified by `folderPath` doesn't exist, no error is thrown — returns an empty array.
 * - Filenames returned do **not** include the folder path, only the filename and extension.
 * - Folders within the specified path are also listed, but their file properties (e.g. `id`) are `null`.
 * - `folderPath` usage:
 *   - `''` lists files in the root directory.
 *   - `'folder1'` lists files inside `folder1` at the root.
 *   - `'folder1/folder2'` lists files inside `folder2` nested in `folder1`.
 *
 * @param folderPath - The path of the folder to list files from.
 * @returns An array of files and folders in the specified path.
 */
export async function ListBucketFiles(folderPath: string) {
    const { data, error } = await supabase
        .storage
        .from(BUCKET_NAME)
        .list(folderPath)

    if (error) {
        console.error(`${error.name}: ${error.message}`);
        return [];
    }

    return data;
}

export function GetFilePublicLink(fileName: string) {
    return supabase.storage.from(BUCKET_NAME).getPublicUrl(fileName).data.publicUrl;
}

/**
 * Uploads a file to the specified `filePath` in the storage bucket.
 *
 * - Automatically creates the folder if it doesn't exist.
 * - Errors if a file with the same name already exists at the destination — the existing file must be deleted first.
 * - If you're replacing a file, prefer using `ReplaceFile()` for efficiency (only one API call instead of two).
 *
 * @param filePath - The full path (including folders and filename) to upload the file to.
 * @param file - The `File` object to upload.
 * @returns `true` if the file was uploaded successfully, otherwise `false`.
 */
export async function UploadFile(filePath: string, file: File) {
    const { error } = await supabase
        .storage
        .from(BUCKET_NAME)
        .upload(filePath, file, { upsert: false });

    if (error) {
        console.error(`${error.name}: ${error.message}`);
        return false;
    }

    return true;
}

/*
 * Remove/delete all files in `filePaths`.
 *
 * - Only accepts an array of file paths. If removing a single file, wrap it in an array.
 * - No error is thrown if 1 or more files in `filePaths` don't exist — existing files will still be removed.
 * - If all files in a folder are removed, the folder is automatically removed.
 * 
 * @param filePaths - The files to remove.
 * @returns `true` if all files were successfully removed, otherwise `false`.
 */
export async function RemoveFiles(filePaths: string[]) {
    const { error } = await supabase
        .storage
        .from(BUCKET_NAME)
        .remove(filePaths);

    if (error) {
        console.error(`${error.name}: ${error.message}`);
        return false;
    }

    return true;
}

/**
 * Replaces the file at the given `fileToReplacePath` with `newFile`.
 *
 * - If the file at `fileToReplacePath` doesn't exist, it behaves like an upload.
 * - File existence is determined by the full path **plus** filename **plus** extension.
 *   - So even a slight mismatch in any of those means the file is considered non-existent.
 *
 * @param fileToReplacePath - Full path (including filename and extension) of the file to replace.
 * @param newFile - The new `File` to upload in place of the existing one.
 * @returns `true` if the file was uploaded/replaced successfully, otherwise `false`.
 */
export async function ReplaceFile(fileToReplacePath: string, newFile: File) {
    const { error } = await supabase
        .storage
        .from(BUCKET_NAME)
        .update(fileToReplacePath, newFile, { upsert: true });

    if (error) {
        console.error(`${error.name}: ${error.message}`);
        return false;
    }

    return true;
}

/**
 * Moves a file
 *
 * - It's possible for `newFilePath` to have a different filename as the original.
 * - Moving folders doesn't work (throws StorageAPIError: Object not found)
 * - If the given `oldFilePath` doesn't exist, the same error will be thrown as above
 * - If the given `newFilePath` already exists, will throw an error (StorageAPIError: The resource already exists)
 * - If `oldFilePath === newFilePath`, nothing happens, no error will be thrown. 
 *
 * @param oldFilePath - The file you want to move.
 * @param newFilePath - The new file path for oldFilePath
 * @returns `true` if successfully moved the file, otherwise `false`.
 */
export async function MoveFile(oldFilePath: string, newFilePath: string) {
    const { error } = await supabase
        .storage
        .from(BUCKET_NAME)
        .move(oldFilePath, newFilePath);

    if (error) {
        console.error(`${error.name}: ${error.message}`);
        return false;
    }

    return true;
}

/**
 * Moves folders recursively.
 *
 * @param oldFolderPath - Old folder path name
 * @param newFolderPath - New folder path name
 */
export async function MoveFolder(oldFolderPath: string, newFolderPath: string) {
    const currentUserFiles = await ListBucketFiles(oldFolderPath);
    if (currentUserFiles.length === 0)
        return;

    for (const file of currentUserFiles) {
        // check if it's a folder
        if (file.id === null)
            await MoveFolder(path.join(oldFolderPath, file.name), path.join(newFolderPath, file.name));
        else 
            await MoveFile(`${oldFolderPath}/${file.name}`, `${newFolderPath}/${file.name}`);
    }
}

