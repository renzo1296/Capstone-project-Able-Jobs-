import { StylesConfig, GroupBase } from 'react-select';

type Option = { value: string; label: string };

const baseSelectStyles = (isDarkMode: boolean) => {
    // helper type for base and state
    type StyleFn<AdditionalState = object> =
        Parameters<NonNullable<
            StylesConfig<Option, boolean, GroupBase<Option>>['control']
        >>[0] & AdditionalState;

    return {
        control: (base: StyleFn) => ({
            ...base,
            background: isDarkMode ? 'var(--surface)' : 'var(--background)',
            borderColor: isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'var(--border-color)',
            '&:hover': {
                borderColor: isDarkMode ? 'rgba(255, 255, 255, 0.2)' : 'var(--primary)',
            },
        }),
        menu: (base: StyleFn) => ({
            ...base,
            background: isDarkMode ? 'var(--surface)' : 'var(--background)',
            border: `1px solid ${
                isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'var(--border-color)'
            }`,
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
        }),
        option: (base: StyleFn, state: { isFocused: boolean }) => ({
            ...base,
            backgroundColor: state.isFocused
                ? isDarkMode
                    ? 'rgba(255, 255, 255, 0.1)'
                    : 'rgba(0, 0, 0, 0.05)'
                : 'transparent',
            color: isDarkMode ? 'var(--foreground)' : 'inherit',
            '&:active': {
                backgroundColor: isDarkMode
                    ? 'rgba(255, 255, 255, 0.2)'
                    : 'var(--primary)',
                color: isDarkMode ? 'var(--foreground)' : 'white',
            },
        }),
        input: (base: StyleFn) => ({
            ...base,
            color: isDarkMode ? 'var(--foreground)' : 'inherit',
        }),
        placeholder: (base: StyleFn) => ({
            ...base,
            color: 'var(--muted)',
        }),
        singleValue: (base: StyleFn) => ({
            ...base,
            color: isDarkMode ? 'var(--foreground)' : 'inherit',
        }),
    };
};

// single select
export const getSingleSelectStyles = (
    isDarkMode: boolean
): StylesConfig<Option, false> => ({
    ...baseSelectStyles(isDarkMode),
});

// multi select
export const getMultiSelectStyles = (
    isDarkMode: boolean
): StylesConfig<Option, true> => ({
    ...baseSelectStyles(isDarkMode),
    multiValue: (base) => ({
        ...base,
        backgroundColor: isDarkMode
            ? 'rgba(255, 255, 255, 0.1)'
            : 'rgba(0, 0, 0, 0.08)',
    }),
    multiValueLabel: (base) => ({
        ...base,
        color: isDarkMode ? 'var(--foreground)' : 'inherit',
    }),
    multiValueRemove: (base) => ({
        ...base,
        color: isDarkMode ? 'var(--foreground)' : 'inherit',
        '&:hover': {
            backgroundColor: isDarkMode
                ? 'rgba(255, 255, 255, 0.2)'
                : 'rgba(0, 0, 0, 0.12)',
            color: isDarkMode ? 'white' : 'inherit',
        },
    }),
});
