import { z } from "zod";
import { WorkExpSchema } from "../components/definitions";

export const jobTypeOptions = [
  { value: 'full_time', label: 'Full Time' },
  { value: 'part_time', label: 'Part Time' },
  { value: 'ojt', label: 'On the Job Training' },
];

export interface MultiSelectOption {
    value: string;
    label: string;
}

export const educationOptions = [
  { value: 'college', label: 'College' },
  { value: 'shs', label: 'Senior High School' },
  { value: 'hs', label: 'High School' },
  { value: 'elem', label: 'Elementary School' },
  { value: 'na', label: 'N/A' },
];

export const MAX_IMAGE_SIZE = 5 * 1000 * 1000;
export const MAX_DOC_SIZE = 10 * 1000 * 1000;
export const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
export const ACCEPTED_DOC_TYPES = ["application/pdf"];

const userTypeEnumValues = ["job_seeker", "admin"] as const;
export const UserTypeEnum = z.enum(userTypeEnumValues);
export type UserTypeEnum = z.infer<typeof UserTypeEnum>;

export const SexEnum = z.enum(["male", "female"]);
export type SexEnum = z.infer<typeof SexEnum>;

export const JobTypeEnum = z.enum(['full_time', 'part_time', 'ojt']);
export type JobTypeEnum = z.infer<typeof JobTypeEnum>;

const jobApplicationStatusEnumValues = ['pending', 'accepted', 'rejected', 'closed'] as const;
export const JobApplicationStatusEnum = z.enum(jobApplicationStatusEnumValues);
export type JobApplicationStatusEnum = z.infer<typeof JobApplicationStatusEnum>;

export const EducationEnum = z.enum(["na", "elem", "hs", "shs", "college"]);
export type EducationEnum = z.infer<typeof EducationEnum>;

export function MultiSelectEnumValue<T extends z.ZodTypeAny>(schema: T) {
  return z.union([z.array(schema), z.tuple([z.literal('')])]);
}

export const MultiSelectEducationEnum = MultiSelectEnumValue(EducationEnum);
export type MultiSelectEducationEnum = z.infer<typeof MultiSelectEducationEnum>;

export const MultiSelectJobTypeEnum = MultiSelectEnumValue(JobTypeEnum);
export type MultiSelectJobTypeEnum = z.infer<typeof MultiSelectJobTypeEnum>;

export const SortByEnum = z.enum(["sort_by_date_posted", "sort_by_salary"]);
export type SortByEnum = z.infer<typeof SortByEnum>;

export interface User {
    id: number;
    firstname: string;
    lastname: string;
    sex: SexEnum;
    birthdate: Date;
    address: string;
    phone_number: string;
    username: string;
    user_type: UserTypeEnum;
    email: string;
    password: string;
    pwd_id_number: string;
    disabilities: MultiSelectOption[];
    work_exp: WorkExpSchema;
    senior_id_number: string;
    sss: string;
    tin: string;
    philhealth: string;
    education: EducationEnum;
    oauth_reset_password_done: boolean;
}
