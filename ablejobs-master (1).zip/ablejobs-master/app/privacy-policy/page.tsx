export default async function PrivacyPolicy() {
    return (
        <main>
            <section>
                <h1>Privacy Policy – AbleJobs</h1>
                <p><strong>Effective Date:</strong> March 2025</p>

                <p>Welcome to AbleJobs. Your privacy is important to us. This Privacy Policy explains how we collect, use, and protect your personal information when you use our platform.</p>

                <h2>1. Introduction</h2>
                <p>By using AbleJobs, you agree to the practices described in this Privacy Policy. Please read it carefully.</p>

                <h2>2. Information We Collect</h2>
                <p>We collect the following types of information:</p>
                <ul>
                    <li><strong>Personal Information:</strong> Name, email, phone number, resume, job preferences, and accessibility needs.</li>
                    <li><strong>Usage Data:</strong> Pages visited, time spent, and interactions on the platform.</li>
                    <li><strong>Cookies & Tracking Data:</strong> Used to improve user experience and platform performance.</li>
                </ul>

                <h2>3. How We Use Your Information</h2>
                <p>We use your information to:</p>
                <ul>
                    <li>Provide job matching and application services</li>
                    <li>Improve user experience and platform functionality</li>
                    <li>Communicate job recommendations and platform updates</li>
                    <li>Ensure security and comply with applicable laws</li>
                </ul>

                <h2>4. How We Protect Your Information</h2>
                <p>We implement security measures such as encryption, secure servers, and restricted access to safeguard your personal data.</p>

                <h2>5. Sharing of Information</h2>
                <p>We do not sell your data. We may share your information with:</p>
                <ul>
                    <li>Employers when you apply for a job (only with your consent)</li>
                    <li>Service providers that support platform operations</li>
                    <li>Legal authorities when required by law</li>
                </ul>

                <h2>6. Your Rights</h2>
                <p>You may access, update, or request deletion of your information anytime by contacting us at <strong>ablejobs@gmail.com</strong>.</p>

                <h2>7. Changes to This Policy</h2>
                <p>We may update this Privacy Policy. Any changes will be communicated via email or through platform notifications. Continued use of AbleJobs indicates acceptance of the updated policy.</p>
            </section>
        </main>
    );
}

