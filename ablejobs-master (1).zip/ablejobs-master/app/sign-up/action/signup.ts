'use server'

import pool from "@/app/lib/db";
import { redirect } from "next/navigation";
import { makeSignUpFormSchema, SignUpState } from "../definitions";
import path from "path";
import { isFileSelected } from "@/app/utils/server/helpers";
import { BUCKET_NAME, 
         CreateBucket, 
         getUserDir, 
         ListBucketFiles, 
         RemoveFiles, 
         UploadFile } from "@/app/lib/supabase";
import { createJobSeeker, handleFileSubmissions, loginUserByEmail } from "@/app/utils/server/userHelper";
import { flattenNonArrayErrors, getWorkExpErrors } from "@/app/components/definitions";
import { parseWorkExp } from "@/app/utils/server/formDataHelper";

export type WorkExpItem = {
    company: string
    position: string
    from: string
    to?: string
    is_present?: boolean
}

export async function signup(prevState: SignUpState, formData: FormData): Promise<SignUpState> {
    const entries = {
        ...Object.fromEntries(formData),
        disabilities: formData.getAll('disabilities')
    };
    console.log("da entries ", typeof(formData));
    console.log("da entries fd", formData);
    console.log("da entries ", typeof(entries));
    console.log("da entries 2zz", entries);

    // Parse workExp dynamically
    const workExpArray = parseWorkExp(formData);
    console.log("Parsed workExp:", workExpArray);

    const signUpFormSchema = await makeSignUpFormSchema();
    const validatedFields = signUpFormSchema.safeParse({
        ...entries,
        work_exp: workExpArray
    });
    console.log("validated res guys:", validatedFields);
    // If any form fields are invalid, return early
    if (!validatedFields.success) {
        console.log("guys it didn't success: ", validatedFields.error.flatten().fieldErrors)
        console.log("guys it didn't success not flattened: ", validatedFields.error)
        const unflattenedErrors = validatedFields.error.issues;
        console.log("guys it issueesss: ", validatedFields.error.issues);

        const fieldErrors = flattenNonArrayErrors(unflattenedErrors, ["work_exp"]);
        const workExpErrors = getWorkExpErrors(unflattenedErrors);

        return {
            errors: {
                ...fieldErrors,
                work_exp: workExpErrors
            }
        };
    }
    console.log("successful validation!! ", validatedFields.data);

    // check first if username already exists
    const query = "SELECT * FROM user_ WHERE username=$1";
    const values = [validatedFields.data.username];
    const res = await pool.query(query, values);
    if (res.rowCount != 0) {
        return { errors: { username: ["Username already exists!"]} };
    }

    await handleFileSubmissions(validatedFields.data);

    const client = await pool.connect();
    try {
        await createJobSeeker(client, validatedFields.data);
        await loginUserByEmail(validatedFields.data.email);
    }
    catch (error: unknown) {
        console.error('Context:', "Database insert error");
        if (error instanceof Error) {
            console.error('Caught error:', error.message);
            return {
                message: "Database insert error: " + error.message,
                isErrorMessage: true
            }
        } 
        else {
            console.error('Unknown error:', error);
            return {
                message: "Database insert unknown error: " + error,
                isErrorMessage: true
            }
        }
    }
    finally {
        client.release();
    }

    redirect("/profile");
}

