import NavLink from "../components/NavLink"
import { getDisabilityOptions } from "../lib/db";
import SignUp from "./components/SignUp"
import styles from "./page.module.css"

export default async function SignUpPage() {
    const disabilityOptions = await getDisabilityOptions();
    console.log("these are da optiooonss from signup: ", disabilityOptions);
    return (
        <main className={styles.sign_up_main_section}>
            <h1>Sign Up</h1>
            <h4>Already have an account? <NavLink href="/login"><span className={styles.login_link}>Login here!</span></NavLink></h4>
            <br />
            <SignUp disabilityOptions={disabilityOptions} />
        </main>
    )
}

