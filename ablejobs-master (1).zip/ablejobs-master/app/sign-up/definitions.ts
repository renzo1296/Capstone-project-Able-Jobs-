import { z } from "zod";
import { isFileSelected } from "@/app/utils/server/helpers";
import { SexEnum, EducationEnum } from "@/app/types/common"
import { WorkExpErrors, WorkExpSchema } from "../components/definitions";
import { makeDisabilitySchema } from "../job-search/definitions";

export type SignUpState = {
    errors?: SignUpStateErrors
    message?: string
    isErrorMessage?: boolean
} | undefined

export type SignUpStateErrors = {
    firstname?: string[]
    lastname?: string[]
    sex?: string[]
    birthdate?: string[]
    address?: string[]
    phone_number?: string[]
    username?: string[]
    email?: string[]
    password?: string[]
    confirm_password?: string[]
    disabilities?: string[]
    profile_pic?: string[]
    pwd_id_pic?: string[]
    resume_file?: string[]
    government_issued_id_pic?: string[]
    nbi_clearance?: string[]
    tor?: string[]
    pwd_id_number?: string[]
    senior_id_number?: string[]
    sss?: string[]
    tin?: string[]
    philhealth?: string[]
    workexp_desc?: string[]
    work_exp?: WorkExpErrors
    education?: string[]
    tos_chkbx?: string[]
}

const MAX_IMAGE_SIZE = 5 * 1000 * 1000;
const MAX_DOC_SIZE = 10 * 1000 * 1000;
const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
const ACCEPTED_DOC_TYPES = ["application/pdf"];

const ImageType = z.instanceof(File)
    .optional()
    .refine(file => !isFileSelected(file) || file!.size <= MAX_IMAGE_SIZE,
        {message: "Max image size is 5MB."})
    .refine(file => !isFileSelected(file) || ACCEPTED_IMAGE_TYPES.includes(file!.type),
        ".jpg, .jpeg, .png, .webp, files are accepted only");

const DocType = z.instanceof(File)
    .optional()
    .refine(file => !isFileSelected(file) || file!.size <= MAX_DOC_SIZE,
        {message: "Max document size is 10MB."})
    .refine(file => !isFileSelected(file) || ACCEPTED_DOC_TYPES.includes(file!.type),
        ".pdf files are accepted only");

export async function makeSignUpFormSchema() {
    return z.object({
        firstname: z
            .string()
            .min(1, { message: 'First name is required.' })
            .max(50, { message: 'First name must be at most 50 characters long.'})
            .trim(),
        lastname: z
            .string()
            .min(1, { message: 'Last name is required.'})
            .max(50, { message: 'Last name must be at most 50 characters long.'})
            .trim(),
        sex: SexEnum,
        birthdate: z.string().date('Must be in YYYY-MM-DD format'),
        address: z
            .string()
            .max(255, {message: 'Address must be at most 255 characters long.'})
            .trim(),
        phone_number: z
            .string()
            .max(15, { message: 'Phone number must be at most 15 characters long.'})
            .trim(),
        username: z
            .string()
            .min(1, { message: 'Username is required.'})
            .max(50, { message: 'Username must be at most 50 characters long.'})
            .trim(),
        email: z
            .string()
            .email({ message: 'Enter a valid email'})
            .max(320, { message: 'Email must be at most 320 characters long.'})
            .trim(),
        password: z
            .string()
            .min(8, { message: 'Password must be at least 8 characters long.'})
            .max(255, { message: 'Password must be at most 255 characters long.'})
            .trim(),
        confirm_password: z.string(),
        disabilities: z.array(await makeDisabilitySchema())
            .transform(disabilities => disabilities.filter(disability => disability !== '')),
        work_exp: WorkExpSchema,
        profile_pic: ImageType,
        pwd_id_pic: ImageType,
        resume_file: DocType,
        government_issued_id_pic: ImageType,
        nbi_clearance: DocType,
        tor: DocType,
        pwd_id_number: z
            .string()
            .min(1, { message: 'PWD ID Number is required.'})
            .max(50, { message: 'PWD ID must be at most 50 characters long.'}),
        senior_id_number: z.string(),
        sss: z.string(),
        tin: z.string(),
        philhealth: z.string(),
        education: EducationEnum
    }).superRefine(({ confirm_password, password }, ctx) => {
        if (confirm_password !== password) {
            ctx.addIssue({
                code: "custom",
                message: "The passwords did not match",
                path: ['confirm_password']
            });
        }
    });
}

export type SignUpFormSchema = z.infer<ReturnType<typeof makeSignUpFormSchema> extends Promise<infer S> ? S : never>;
