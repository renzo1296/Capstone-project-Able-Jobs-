'use client'

import styles from "./SignUp.module.css"
import React, { useState, startTransition, useActionState } from "react"
import { signup } from "../action/signup"
import Link from "next/link"
import FileUpload, { FileType } from "@/app/components/FileUpload"
import WorkExp from "@/app/components/WorkExp"
import Select from "react-select"
import { MultiSelectOption } from "@/app/types/common"
import { useTheme } from "@/app/context/ThemeContext"
import { getMultiSelectStyles } from "@/app/types/styles"
import { createPortal } from "react-dom"
import ConfirmationModal from "@/app/components/ConfirmationModal"
import TermsOfService from "@/app/components/TermsOfService"

interface SignUpProps {
    disabilityOptions: MultiSelectOption[]
}

export default function SignUp({ disabilityOptions }: SignUpProps) {
    const { theme } = useTheme();
    const isDarkMode = theme === 'dark';
    const multiSelectStyles = getMultiSelectStyles(isDarkMode);

    const [signUpState, signUpAction, pending] = useActionState(signup, undefined);
    const [selectedSex, setSelectedSex] = useState('');
    const [isShowingTos, setIsShowingTos] = useState(false);
    const [isAcceptedTos, setIsAcceptedTos] = useState(false);

    const handleTosClick = () => {
        if (isAcceptedTos) setIsAcceptedTos(false);
        else setIsShowingTos(true);
    }
    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        startTransition(() => signUpAction(formData));
    };

    const handleSelectedSexChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setSelectedSex(event.target.value);
    }

    return (
        <form onSubmit={handleSubmit} className={styles.signup_form}>
            {
                isShowingTos && 
                createPortal(
                    <ConfirmationModal
                        message = "Please review and accept the Terms of Service to continue."
                        yesText = "Agree"
                        noText = "Disagree"
                        onNo={() => setIsShowingTos(false)}
                        onYes={() => { setIsShowingTos(false); setIsAcceptedTos(true); }} 
                    >
                        <TermsOfService />
                    </ConfirmationModal>
                    , globalThis.document.body)
            }
            <div className={styles.signup_form_left}>
                <h2 className={styles.section_title}>Personal Information</h2>
                
                <label htmlFor="firstname">First Name</label>
                {signUpState?.errors?.firstname && 
                    <p className={styles.error_msg}>{signUpState.errors.firstname}</p>
                }
                <input 
                    className={styles.signup_input} 
                    type="text" 
                    id="firstname" 
                    name="firstname"
                    placeholder="Enter your first name"
                />

                <label htmlFor="lastname">Last Name</label>
                {signUpState?.errors?.lastname && 
                    <p className={styles.error_msg}>{signUpState.errors.lastname}</p>
                }
                <input 
                    className={styles.signup_input} 
                    type="text" 
                    id="lastname" 
                    name="lastname"
                    placeholder="Enter your last name"
                />

                <label>Sex</label>
                {signUpState?.errors?.sex && 
                    <p className={styles.error_msg}>{signUpState.errors.sex}</p>
                }
                <div className={styles.radio_group}>
                    <label>
                        <input 
                            className={styles.signup_input_radio}
                            type="radio"
                            id="male"
                            name="sex"
                            onChange={handleSelectedSexChange}
                            checked={selectedSex === 'male'}
                            value="male"
                        />
                        Male
                    </label>
                    <label>
                        <input 
                            className={styles.signup_input_radio}
                            type="radio"
                            id="female"
                            name="sex"
                            onChange={handleSelectedSexChange}
                            checked={selectedSex === 'female'}
                            value="female"
                        />
                        Female
                    </label>
                </div>

                <label htmlFor="birthdate">Birthdate</label>
                {signUpState?.errors?.birthdate && 
                    <p className={styles.error_msg}>{signUpState.errors.birthdate}</p>
                }
                <input 
                    className={styles.signup_input}
                    type="date"
                    id="birthdate"
                    name="birthdate"
                />

                <h2 className={styles.section_title}>Contact Details</h2>

                <label htmlFor="address">Address</label>
                {signUpState?.errors?.address && 
                    <p className={styles.error_msg}>{signUpState.errors.address}</p>
                }
                <input 
                    className={styles.signup_input}
                    type="text"
                    id="address"
                    name="address"
                    placeholder="Enter your complete address"
                />

                <label htmlFor="phone_number">Phone Number</label>
                {signUpState?.errors?.phone_number && 
                    <p className={styles.error_msg}>{signUpState.errors.phone_number}</p>
                }
                <input 
                    className={styles.signup_input}
                    type="text"
                    id="phone_number"
                    name="phone_number"
                    placeholder="Enter your phone number"
                />

                <label htmlFor="email">Email</label>
                {signUpState?.errors?.email && 
                    <p className={styles.error_msg}>{signUpState.errors.email}</p>
                }
                <input 
                    className={styles.signup_input}
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter your email address"
                />

                <h2 className={styles.section_title}>Account Security</h2>

                <label htmlFor="username">Username</label>
                {signUpState?.errors?.username && 
                    <p className={styles.error_msg}>{signUpState.errors.username}</p>
                }
                <input 
                    className={styles.signup_input}
                    type="text"
                    id="username"
                    name="username"
                    placeholder="Choose a username"
                />

                <label htmlFor="password">Password</label>
                {signUpState?.errors?.password && 
                    <p className={styles.error_msg}>{signUpState.errors.password}</p>
                }
                <input 
                    className={styles.signup_input}
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter your password"
                />

                <label htmlFor="confirm_password">Confirm Password</label>
                {signUpState?.errors?.confirm_password && 
                    <p className={styles.error_msg}>{signUpState.errors.confirm_password}</p>
                }
                <input 
                    className={styles.signup_input}
                    type="password"
                    id="confirm_password"
                    name="confirm_password"
                    placeholder="Confirm your password"
                />
            </div>

            <div className={styles.signup_form_right}>

                <h2 className={styles.section_title}>Additional Information</h2>

                <WorkExp work_exp_errors={signUpState?.errors?.work_exp} />

                <label htmlFor="disabilities">Disabilities</label>
                {signUpState?.errors?.disabilities && 
                    <p className={styles.error_msg}>{signUpState.errors.disabilities}</p>
                }
                <Select
                    isMulti
                    options={disabilityOptions}
                    placeholder="Select disabilities"
                    closeMenuOnSelect={false}
                    className={styles.multiselect_input}
                    inputId="disabilities"
                    name="disabilities"
                    styles={multiSelectStyles}
                />

                <FileUpload 
                    id="profile_pic"
                    name="profile_pic"
                    labelText="Profile Picture"
                    errorText={signUpState?.errors?.profile_pic}
                />

                <FileUpload 
                    id="pwd_id_pic"
                    name="pwd_id_pic"
                    labelText="PWD ID"
                    errorText={signUpState?.errors?.pwd_id_pic}
                />

                <FileUpload 
                    id="resume_file"
                    name="resume_file"
                    labelText="Resume"
                    errorText={signUpState?.errors?.resume_file}
                    type={FileType.Document}
                />

                <FileUpload 
                    id="government_issued_id_pic"
                    name="government_issued_id_pic"
                    labelText="Government-Issued ID"
                    errorText={signUpState?.errors?.government_issued_id_pic}
                    type={FileType.Image}
                />

                <FileUpload 
                    id="nbi_clearance"
                    name="nbi_clearance"
                    labelText="NBI Clearance"
                    errorText={signUpState?.errors?.nbi_clearance}
                    type={FileType.Document}
                />

                <FileUpload 
                    id="tor"
                    name="tor"
                    labelText="Transcript of Records (TOR)"
                    errorText={signUpState?.errors?.tor}
                    type={FileType.Document}
                />

                <label htmlFor="pwd_id_number">PWD ID Number</label>
                {signUpState?.errors?.pwd_id_number && 
                    <p className={styles.error_msg}>{signUpState.errors.pwd_id_number}</p>
                }
                <input 
                    className={styles.signup_input}
                    type="text"
                    id="pwd_id_number"
                    name="pwd_id_number"
                    minLength={1}
                    maxLength={50}
                    placeholder="Enter your PWD ID number"
                />
                
                <label htmlFor="senior_id_number">Senior ID Number</label>
                {signUpState?.errors?.senior_id_number && 
                    <p className={styles.error_msg}>{signUpState.errors.senior_id_number}</p>
                }
                <input 
                    className={styles.signup_input} 
                    type="text" 
                    id="senior_id_number" 
                    name="senior_id_number" 
                    placeholder="Enter your Senior ID number"
                />

                <label htmlFor="sss">SSS</label>
                {signUpState?.errors?.sss && 
                    <p className={styles.error_msg}>{signUpState.errors.sss}</p>
                }
                <input 
                    className={styles.signup_input} 
                    type="text" 
                    id="sss" 
                    name="sss" 
                    placeholder="Enter your SSS Number"
                />

                <label htmlFor="tin">TIN</label>
                {signUpState?.errors?.tin && 
                    <p className={styles.error_msg}>{signUpState.errors.tin}</p>
                }
                <input 
                    className={styles.signup_input} 
                    type="text" 
                    id="tin" 
                    name="tin" 
                    placeholder="Enter your TIN"
                />

                <label htmlFor="philhealth">Philhealth</label>
                {signUpState?.errors?.philhealth && 
                    <p className={styles.error_msg}>{signUpState.errors.philhealth}</p>
                }
                <input 
                    className={styles.signup_input} 
                    type="text" 
                    id="philhealth" 
                    name="philhealth" 
                    placeholder="Enter your Philhealth number"
                />

                <label htmlFor="education">Educational Attainment</label>
                <p className={styles.helper_text}>
                    Select N/A if you have no formal education
                </p>
                {signUpState?.errors?.education && 
                    <p className={styles.error_msg}>{signUpState.errors.education}</p>
                }
                <select className={styles.signup_input} id="education" name="education">
                    <option value="na">N/A</option>
                    <option value="elem">Elementary School</option>
                    <option value="hs">High School</option>
                    <option value="shs">Senior High School</option>
                    <option value="college">College</option>
                </select>

                <div className={styles.chkbox_w_label}>
                    <input 
                        type="checkbox"
                        id="tos_chkbox"
                        required
                        name="tos_chkbox"
                        onClick={handleTosClick}
                        checked={isAcceptedTos}
                    />
                    <label htmlFor="tos_chkbox">
                        By signing up you agree to AbleJobs{' '}
                        <Link 
                            href="terms-of-service"
                            target="_blank"
                            style={{ color: 'var(--primary)' }}
                        >
                            Terms of Services
                        </Link>
                        . Your information will be used to help you find suitable jobs.
                    </label>
                </div>

                {signUpState?.message && (
                    <p className={signUpState.isErrorMessage ? styles.error_flash : styles.success_flash}>
                        {signUpState?.message}
                    </p>
                )}

                <button 
                    type="submit"
                    className={`${styles.signup_btn} ${pending ? styles.signup_btn_disabled : ''}`}
                    disabled={pending}
                >
                    {pending ? 'Creating Account...' : 'Create Account'}
                </button>
            </div>
        </form>
    )
}
