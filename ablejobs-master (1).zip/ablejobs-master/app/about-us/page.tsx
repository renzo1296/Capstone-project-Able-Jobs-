import styles from "./page.module.css"

export default function AboutUs() {
    return (
        <main>
            <h1>About Us</h1>
            <p>Welcome to AbleJobs — Where Ability Meets Opportunity.</p>
            <p>
                At AbleJobs, we believe that everyone deserves the chance to thrive in a career they love. Our mission is to empower Persons With Disabilities (PWD) by connecting them with inclusive employers who recognize the strength in diversity.
                We know the job search journey can be challenging, especially when facing accessibility barriers. That’s why we’ve built a platform that puts inclusivity first — from accessible job listings to personalized support and resources that meet your unique needs.
            </p>
            What We Do:<br />
            <ul className={styles.about_ul}>
                <li>Curate inclusive job listings from verified, disability-friendly employers</li>
                <li>Partner with organizations committed to accessible hiring practices</li>
                <li>Provide resources, career guidance, and support for every step of your journey</li>
            </ul>

            <p>Together, we’re breaking down barriers and building a future where everyone has the opportunity to work with dignity, purpose, and pride.</p>
        </main>
    )
}
