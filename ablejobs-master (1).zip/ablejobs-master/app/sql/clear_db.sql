DROP TABLE IF EXISTS job_application_;
DROP TABLE IF EXISTS job_disability_type_;
DROP TABLE IF EXISTS job_;
DROP TABLE IF EXISTS disability_type_;
DROP TABLE IF EXISTS city_;
DROP TABLE IF EXISTS job_seeker_;
DROP TABLE IF EXISTS admin_;
DROP TABLE IF EXISTS user_;
DROP TABLE IF EXISTS user_type_;

DROP TYPE IF EXISTS job_application_status_;
DROP TYPE IF EXISTS job_type_;
DROP TYPE IF EXISTS education_;
DROP TYPE IF EXISTS sex_;

