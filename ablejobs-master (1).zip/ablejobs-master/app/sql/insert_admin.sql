WITH new_user AS (
    INSERT INTO user_ (user_type, username, email, password)
    VALUES ('admin', 'admin1', 'admin1@example.com', 'admin1admin1')
    RETURNING id
)
INSERT INTO admin_ (user_id, firstname, lastname)
SELECT id, 'fname', 'lname'
FROM new_user;

