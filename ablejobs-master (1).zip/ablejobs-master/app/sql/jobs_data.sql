-- Original 4 jobs, refactored to use WITH + RETURNING

-- 1. Junior Developer
WITH new_job AS (
  INSERT INTO job_ (
    company_name, job_title, job_type, job_details,
    city_name, location, monthly_salary, education, date_posted
  )
  VALUES (
    'ABC Corp', 'Junior Developer', 'full_time',
    'Write backend code and assist in deployment.',
    'qc', '3rd Floor, IT Hub', 25000.00, 'college', '2025-05-14'
  )
  RETURNING id
)
INSERT INTO job_disability_type_ (job_id, disability_type)
VALUES
  ((SELECT id FROM new_job), 'dyslexia'),
  ((SELECT id FROM new_job), 'deaf');

-- 2. Graphic Designer Intern
WITH new_job AS (
  INSERT INTO job_ (
    company_name, job_title, job_type, job_details,
    city_name, location, monthly_salary, education, date_posted
  )
  VALUES (
    'XYZ Inc', 'Graphic Designer Intern', 'ojt',
    'Design posters and marketing materials.',
    'antipolo', 'Creative Building, Room 5', 8000.00, 'shs', '2025-05-13'
  )
  RETURNING id
)
INSERT INTO job_disability_type_ (job_id, disability_type)
VALUES ((SELECT id FROM new_job), 'speech_disorder');

-- 3. Store Assistant
WITH new_job AS (
  INSERT INTO job_ (
    company_name, job_title, job_type, job_details,
    city_name, location, monthly_salary, education, date_posted
  )
  VALUES (
    'FreshMart Inc', 'Store Assistant', 'part_time',
    'Assist customers, stock shelves, and manage the cashier counter.',
    'qc', 'FreshMart Ground Floor', 12000.00, 'hs', '2025-05-14'
  )
  RETURNING id
)
INSERT INTO job_disability_type_ (job_id, disability_type)
VALUES
  ((SELECT id FROM new_job), 'deaf'),
  ((SELECT id FROM new_job), 'speech_disorder');

-- 4. IT Support Intern
WITH new_job AS (
  INSERT INTO job_ (
    company_name, job_title, job_type, job_details,
    city_name, location, monthly_salary, education, date_posted
  )
  VALUES (
    'SoftWorks Ltd', 'IT Support Intern', 'ojt',
    'Help maintain internal IT systems and assist with troubleshooting.',
    'antipolo', 'SoftWorks Tech Park', 6000.00, 'shs', '2025-05-14'
  )
  RETURNING id
)
INSERT INTO job_disability_type_ (job_id, disability_type)
VALUES
  ((SELECT id FROM new_job), 'dwarfism'),
  ((SELECT id FROM new_job), 'dyslexia');

-- ========================
-- Additional 5 jobs
-- ========================

-- 5. Office Clerk
WITH new_job AS (
  INSERT INTO job_ (
    company_name, job_title, job_type, job_details,
    city_name, location, monthly_salary, education, date_posted
  )
  VALUES (
    'Clerkify', 'Office Clerk', 'full_time',
    'Handle filing and administrative tasks.',
    'qc', 'Clerkify Tower', 18000.00, 'hs', '2025-05-15'
  )
  RETURNING id
)
INSERT INTO job_disability_type_ (job_id, disability_type)
VALUES ((SELECT id FROM new_job), 'speech_disorder');

-- 6. Barista
WITH new_job AS (
  INSERT INTO job_ (
    company_name, job_title, job_type, job_details,
    city_name, location, monthly_salary, education, date_posted
  )
  VALUES (
    'Bean Brew', 'Barista', 'part_time',
    'Prepare drinks and serve customers.',
    'antipolo', 'Bean Brew Cafe', 10000.00, 'shs', '2025-05-15'
  )
  RETURNING id
)
INSERT INTO job_disability_type_ (job_id, disability_type)
VALUES ((SELECT id FROM new_job), 'deaf');

-- 7. QA Tester
WITH new_job AS (
  INSERT INTO job_ (
    company_name, job_title, job_type, job_details,
    city_name, location, monthly_salary, education, date_posted
  )
  VALUES (
    'Testify', 'QA Tester', 'full_time',
    'Test software applications and report bugs.',
    'qc', 'Testify HQ', 27000.00, 'college', '2025-05-15'
  )
  RETURNING id
)
INSERT INTO job_disability_type_ (job_id, disability_type)
VALUES ((SELECT id FROM new_job), 'dyslexia');

-- 8. Web Design Intern
WITH new_job AS (
  INSERT INTO job_ (
    company_name, job_title, job_type, job_details,
    city_name, location, monthly_salary, education, date_posted
  )
  VALUES (
    'PixelCraft', 'Web Design Intern', 'ojt',
    'Assist in creating website layouts and visuals.',
    'antipolo', 'PixelCraft Studio', 7000.00, 'college', '2025-05-15'
  )
  RETURNING id
)
INSERT INTO job_disability_type_ (job_id, disability_type)
VALUES ((SELECT id FROM new_job), 'speech_disorder');

-- 9. Delivery Assistant
WITH new_job AS (
  INSERT INTO job_ (
    company_name, job_title, job_type, job_details,
    city_name, location, monthly_salary, education, date_posted
  )
  VALUES (
    'QuickMove', 'Delivery Assistant', 'part_time',
    'Help with logistics and last-mile delivery.',
    'qc', 'QuickMove Logistics Hub', 11000.00, 'hs', '2025-05-15'
  )
  RETURNING id
)
INSERT INTO job_disability_type_ (job_id, disability_type)
VALUES ((SELECT id FROM new_job), 'dwarfism');
