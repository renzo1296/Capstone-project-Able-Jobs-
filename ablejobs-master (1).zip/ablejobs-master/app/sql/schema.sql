CREATE TYPE sex_ AS ENUM ('male', 'female');

CREATE TYPE education_ AS ENUM ('na', 'elem', 'hs', 'shs', 'college');

CREATE TYPE job_type_ AS ENUM ('full_time', 'part_time', 'ojt');

CREATE TYPE job_application_status_ AS ENUM ('pending', 'accepted', 'rejected', 'closed');

CREATE TABLE city_ (
    city varchar(50) PRIMARY KEY,
    name varchar(50) NOT NULL
);
INSERT INTO city_ (city, name) VALUES
('antipolo', 'Antipolo'),
('quezon_city', 'Quezon City');

CREATE TABLE user_type_ (
    type varchar(50) PRIMARY KEY,
    name varchar(50) NOT NULL
);
INSERT INTO user_type_ (type, name) VALUES
('job_seeker', 'Job Seeker'),
('admin', 'Admin');

CREATE TABLE user_ (
    id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_type VARCHAR(50) NOT NULL REFERENCES user_type_(type),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(320) NOT NULL,
    password VARCHAR(255) NOT NULL,
    oauth_reset_password_done BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE job_seeker_ (
    user_id int PRIMARY KEY REFERENCES user_(id) ON DELETE CASCADE,
    firstname varchar(50) NOT NULL,
    lastname varchar(50) NOT NULL,
    sex sex_ NOT NULL,
    birthdate date NOT NULL,
    address varchar(255) NOT NULL,
    phone_number varchar(15) NOT NULL,
    pwd_id_number varchar(50) NOT NULL,
    senior_id_number varchar(50) NOT NULL,
    sss varchar(50) NOT NULL,
    tin varchar(50) NOT NULL,
    philhealth varchar(50) NOT NULL,
    education education_ NOT NULL
);

CREATE TABLE work_exp_ (
    id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id INT NOT NULL REFERENCES job_seeker_(user_id) ON DELETE CASCADE,
    company VARCHAR(100) NOT NULL,
    position VARCHAR(100) NOT NULL,
    from_date DATE NOT NULL,
    to_date DATE,
    is_present BOOLEAN NOT NULL DEFAULT false
);

CREATE TABLE admin_ (
    user_id INT PRIMARY KEY REFERENCES user_(id),
    firstname varchar(50) NOT NULL,
    lastname varchar(50) NOT NULL
);

CREATE TABLE job_ (
    id int PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    company_name varchar(100) NOT NULL,
    job_title varchar(100) NOT NULL,
    job_type job_type_ NOT NULL,
    job_details TEXT,
    city_name varchar(50) NOT NULL references city_(city),
    location varchar(100) NOT NULL,
    monthly_salary decimal(10, 2) NOT NULL,
    education education_ NOT NULL,
    date_posted date NOT NULL,
    deleted boolean DEFAULT false
);

CREATE TABLE job_application_ (
    user_id int NOT NULL references user_(id),
    job_id int NOT NULL references job_(id),
    status job_application_status_ NOT NULL,
    date_applied TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (user_id, job_id)
);

CREATE TABLE disability_type_ (
    type varchar(50) PRIMARY KEY,
    name varchar(50) NOT NULL
);
INSERT INTO disability_type_ (type, name) VALUES
('deaf', 'Deaf'),
('dwarfism', 'Dwarfism'),
('dyslexia', 'Dyslexia'),
('speech_disorder', 'Speech Disorder'),
('other', 'Other');

CREATE TABLE job_disability_type_ (
    job_id int NOT NULL references job_(id),
    disability_type varchar(50) NOT NULL references disability_type_(type),
    PRIMARY KEY (job_id, disability_type)
);

CREATE TABLE job_seeker_disability_type_ (
    user_id INT NOT NULL REFERENCES user_(id) ON DELETE CASCADE,
    disability_type VARCHAR(50) NOT NULL REFERENCES disability_type_(type) ON DELETE CASCADE,
    PRIMARY KEY (user_id, disability_type)
);

