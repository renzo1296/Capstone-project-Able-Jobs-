'use server'

import pool from "@/app/lib/db"
import { JobSearchFormSchema, JobSearchState, makeJobSearchFormSchema } from "../definitions";
import { Job } from "@/app/job/[id]/definitions";

export async function getJobsBySearchFilters(prevState: JobSearchState, formData: FormData): Promise<JobSearchState> {
    const entries = {
        'company_name': formData.get('company_name'),
        'job_title': formData.get('job_title'),
        'job_type': formData.getAll('job_type'),
        'city': formData.getAll('city'),
        'monthly_salary_range_start': formData.get('monthly_salary_range_start'),
        'monthly_salary_range_end': formData.get('monthly_salary_range_end'),
        'location': formData.get('location'),
        'disabilities': formData.getAll('disabilities'),
        'education': formData.getAll('education'),
        'sort_by': formData.get('sort_by')
    };

    const jobSearchFormSchema = await makeJobSearchFormSchema();
    const validatedEntries = jobSearchFormSchema.safeParse(entries);

    if (!validatedEntries.success) {
        console.log(validatedEntries.error.flatten().fieldErrors)
        return {
            errors: validatedEntries.error.flatten().fieldErrors,
        }
    }

    const searchResult = await searchJobsInDBWithFilters(validatedEntries.data);

    return {
        jobs: searchResult
    };
}

export async function searchJobsInDBWithFilters(jobSearchFilters: JobSearchFormSchema): Promise<Job[]> {
    const conditions: string[] = [];
    const values: (string | number)[] = [];

    const disabilities: string[] = [];
    if (jobSearchFilters.disabilities.length !== 0) {
        for (const disability of jobSearchFilters.disabilities) {
            values.push(`${disability}`);
            disabilities.push(`$${values.length}`);
        }
    }

    const tableFrom = jobSearchFilters.disabilities.length !== 0 ? 
    `(
        SELECT DISTINCT j.* 
        FROM job_ j
        JOIN job_disability_type_ jdt ON jdt.job_id = j.id
        JOIN disability_type_ dt ON dt.type = jdt.disability_type
        WHERE dt.type IN (${disabilities.join(', ')})
    ) as filtered_job_`
    : 'job_';

    
    if (jobSearchFilters.company_name) {
        values.push(`%${jobSearchFilters.company_name}%`);
        conditions.push(`company_name ILIKE $${values.length}`);
    }
    if (jobSearchFilters.job_title) {
        values.push(`%${jobSearchFilters.job_title}%`);
        conditions.push(`job_title ILIKE $${values.length}`);
    }
    if (jobSearchFilters.location) {
        values.push(`%${jobSearchFilters.location}%`);
        conditions.push(`location ILIKE $${values.length}`);
    }

    if (jobSearchFilters.job_type.length !== 0) {
        const job_types: string[] = [];
        for (const job_type of jobSearchFilters.job_type) {
            values.push(job_type);
            job_types.push(`$${values.length}`);
        }
        conditions.push(`job_type IN (${job_types.join(', ')})`);
    }

    if (jobSearchFilters.city.length !== 0) {
        const cities: string[] = [];
        for (const city of jobSearchFilters.city) {
            values.push(city);
            cities.push(`$${values.length}`);
        }
        conditions.push(`city_name IN (${cities.join(', ')})`);
    }

    if (jobSearchFilters.education.length !== 0) {
        const educations: string[] = [];
        for (const education of jobSearchFilters.education) {
            values.push(`${education}`);
            educations.push(`$${values.length}`);
        }
        conditions.push(`education IN (${educations.join(', ')})`);
    }

    values.push(jobSearchFilters.monthly_salary_range_start);
    conditions.push(`monthly_salary >= $${values.length}`);
    if (jobSearchFilters.monthly_salary_range_end !== 0) {
        values.push(jobSearchFilters.monthly_salary_range_end);
        conditions.push(`monthly_salary <= $${values.length}`);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const orderByClause = `ORDER BY ${jobSearchFilters.sort_by === 'sort_by_date_posted' ? 'date_posted' : 'monthly_salary'}`;
    const query = `SELECT * FROM ${tableFrom} ${whereClause} ${orderByClause};`;

    console.log("the query: ", query);

    const result = await pool.query<Job>(query, values);
    console.log("the database query result: ", result.rows);

    return result.rows;
}
