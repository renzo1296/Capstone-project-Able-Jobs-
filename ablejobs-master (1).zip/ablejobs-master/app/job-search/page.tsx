import { getCityOptions, getDisabilityOptions } from '../lib/db';
import JobSearch from './components/JobSearch'
import styles from './page.module.css'

export default async function Page() {
    const cityOptions = await getCityOptions();
    const disabilityOptions = await getDisabilityOptions();
    console.log("these are da optiooonss from job search: ", disabilityOptions);

    return (
        <div className={styles.job_search_page}>
            <JobSearch cityOptions={cityOptions} disabilityOptions={disabilityOptions} />
        </div>
    )
}
