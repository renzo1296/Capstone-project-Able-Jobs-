import { z } from "zod";
import { MultiSelectJobTypeEnum,
         MultiSelectEducationEnum, 
         SortByEnum } from '@/app/types/common'
import { Job } from "../job/[id]/definitions";
import { getCityKeysDb, getDisabilityTypesDb } from "../lib/db";

export type JobSearchState = {
    jobs?: Job[],
    errors?: JobSearchStateErrors
    message?: string
    isErrorMessage?: boolean
} | undefined

export type JobSearchStateErrors = {
    company_name?: string[]
    job_title?: string[]
    job_type?: string[]
    city?: string[]
    monthly_salary_range_start?: string[]
    monthly_salary_range_end?: string[]
    location?: string[]
    disabilities?: string[]
    education?: string[]
    sort_by?: string[]
}


export async function makeCitySchema(allowEmpty: boolean=true) {
    const cityRows = await getCityKeysDb();
    const cityKeys = cityRows.map(row => row.city);
    return z.string().refine(
        (val) => (allowEmpty && val === '') || cityKeys.includes(val),
        { message: "Invalid city type" }
    );
}

export async function makeDisabilitySchema() {
    const disabilityRows = await getDisabilityTypesDb();
    const disabilityTypes = disabilityRows.map(row => row.type);
    return z.string().refine(
        (val) => val === '' || disabilityTypes.includes(val),
        { message: "Invalid disability type" }
    );
}
export type DisabilitySchema = z.infer<ReturnType<typeof makeDisabilitySchema> extends Promise<infer S> ? S : never>;

export async function makeJobSearchFormSchema() {
    return z.object({
        company_name: z
            .string()
            .max(100, { message: 'Company name must be at most 100 characters long.' })
            .trim(),
        job_title: z
            .string()
            .max(100, { message: 'Job title must be at most 100 characters long.' })
            .trim(),
        job_type: MultiSelectJobTypeEnum
            .transform(job_types => job_types.filter(job_type => job_type !== '')),
        city: z.array(await makeCitySchema()) 
            .transform(cities => cities.filter(city => city !== '')),
        monthly_salary_range_start: z
            .string()
            .refine(val => !isNaN(Number(val)), {
                message: "Must be a numeric string",
            })
            .transform(val => Number(val))
            .pipe(
                z
                .number()
                .min(0, { message: "Monthly salary must be at least 0" })
                .max(9999999999, { message: "Monthly salary must be less than 9,999,999,999" })
            ),
        monthly_salary_range_end: z
            .string()
            .refine(val => !isNaN(Number(val)), {
                message: "Must be a numeric string",
            })
            .transform(val => Number(val))
            .pipe(
                z
                .number()
                .min(0, { message: "Monthly salary must be at least 0" })
                .max(9999999999, { message: "Monthly salary must be less than 9,999,999,999" })
            ),
        location: z
            .string()
            .max(100, { message: 'Location must be at most 100 characters long.' })
            .trim(),
        disabilities: z.array(await makeDisabilitySchema())
            .transform(disabilities => disabilities.filter(disability => disability !== '')),
        education: MultiSelectEducationEnum
            .transform(educations => educations.filter(education => education !== '')),
        sort_by: SortByEnum
    }).superRefine(({ monthly_salary_range_start, monthly_salary_range_end }, ctx) => {
        if (monthly_salary_range_start > monthly_salary_range_end) {
            ctx.addIssue({
                code: "custom",
                message: "Invalid range: Monthly salary end range should be greater than or equal to the monthly salary start range.",
                path: ['monthly_salary_range_end']
            });
        }
    });
}
export type JobSearchFormSchema = z.infer<ReturnType<typeof makeJobSearchFormSchema> extends Promise<infer S> ? S : never>;
