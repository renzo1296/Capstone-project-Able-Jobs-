'use client'
import { useTheme } from '@/app/context/ThemeContext'
import styles from "./JobSearchForm.module.css"
import Select from "react-select"
import { useSearchParams } from 'next/navigation'
import { useRef, useEffect, startTransition } from "react"
import { educationOptions, jobTypeOptions, MultiSelectOption } from "@/app/types/common"
import { JobSearchState } from "../definitions"
import { getMultiSelectStyles } from '@/app/types/styles'

interface JobSearchFormProps {
    cityOptions: MultiSelectOption[];
    disabilityOptions: MultiSelectOption[];
    jobSearchState: JobSearchState;
    jobSearchAction: (formData: FormData) => void;
    pending: boolean;
}

export default function JobSearchForm({ cityOptions, disabilityOptions, jobSearchState, jobSearchAction, pending }: JobSearchFormProps) {
    const { theme } = useTheme();
    const isDarkMode = theme === 'dark';
    const multiSelectStyles = getMultiSelectStyles(isDarkMode);
    const formRef = useRef<HTMLFormElement>(null)

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        startTransition(() => jobSearchAction(formData))
    };

    useEffect(() => {
        if (formRef.current) {
            const formData = new FormData(formRef.current);
            startTransition(() => jobSearchAction(formData))
        }
    }, [jobSearchAction])

    const searchParams = useSearchParams()
    const search = searchParams.get('search');
    const jobId = searchParams.get('jobId');
    console.log("the search params: ", searchParams);
    console.log("was params retrieved?? : ", search, jobId);


    return (
        <form onSubmit={handleSubmit} className={styles.update_form} ref={formRef}>
            <h2 className={styles.search_area_h2}>Filter By:</h2>
            <label className={styles.search_input_lbl} htmlFor="company_name">Company Name</label>
            { jobSearchState?.errors?.company_name && <p className={styles.error_msg}>{ jobSearchState.errors.company_name }</p> }
            <input className={styles.search_input} type="text" name="company_name" id="company_name" placeholder={"Enter company name"} />

            <label className={styles.search_input_lbl} htmlFor="job_title">Job Title</label>
            { jobSearchState?.errors?.job_title && <p className={styles.error_msg}>{ jobSearchState.errors.job_title }</p> }
            <input className={styles.search_input} type="text" name="job_title" id="job_title" placeholder={"Enter job title"} />

            <label className={styles.search_input_lbl} htmlFor="job_type">Job Type</label>
            { jobSearchState?.errors?.job_type && <p className={styles.error_msg}>{ jobSearchState.errors.job_type }</p> }
            <Select
                //defaultValue={[jobTypeOptions[0]]}
                isMulti
                options={jobTypeOptions}
                placeholder="Select job type"
                closeMenuOnSelect={false}
                className={styles.search_input_react_select}
                inputId="job_type"
                name="job_type"
                styles={multiSelectStyles}
            />

            <label className={styles.search_input_lbl} htmlFor="city">City</label>
            { jobSearchState?.errors?.city && <p className={styles.error_msg}>{ jobSearchState.errors.city }</p> }
            <Select
                isMulti
                options={cityOptions}
                placeholder="Select city"
                closeMenuOnSelect={false}
                className={styles.search_input_react_select}
                inputId="city"
                name="city"
                styles={multiSelectStyles}
            />

            <div>
                <span className={styles.search_input_lbl}>Monthly Salary Range</span>
                <div className={styles.monthly_salary_range_input_container}>
                    <div>
                        <label className={styles.search_input_lbl + ' ' + styles.search_input_nbr_lbl} htmlFor="monthly_salary_range_start">From: </label>
                        { jobSearchState?.errors?.monthly_salary_range_start && <p className={styles.error_msg}>{ jobSearchState.errors.monthly_salary_range_start }</p> }
                        <input className={styles.search_input} type="number" defaultValue={0} min={0} max={9999999999} id="monthly_salary_range_start" name="monthly_salary_range_start" />
                    </div>
                    <span>-</span>
                    <div>
                        <label className={styles.search_input_lbl + ' ' + styles.search_input_nbr_lbl} htmlFor="monthly_salary_range_end">To: </label>
                        { jobSearchState?.errors?.monthly_salary_range_end && <p className={styles.error_msg}>{ jobSearchState.errors.monthly_salary_range_end }</p> }
                        <input className={styles.search_input} type="number" defaultValue={0} min={0} max={9999999999} id="monthly_salary_range_end"  name="monthly_salary_range_end" />
                    </div>
                </div>
            </div>

            <label className={styles.search_input_lbl} htmlFor="location">Location</label>
            { jobSearchState?.errors?.location && <p className={styles.error_msg}>{ jobSearchState.errors.location }</p> }
            <input className={styles.search_input} type="text" name="location" id="location" placeholder={"Enter location"} />

            <label className={styles.search_input_lbl} htmlFor="disabilities">Disabilities</label>
            { jobSearchState?.errors?.disabilities && <p className={styles.error_msg}>{ jobSearchState.errors.disabilities }</p> }
            <Select
                isMulti
                options={disabilityOptions}
                placeholder="Select disability"
                closeMenuOnSelect={false}
                className={styles.search_input_react_select}
                inputId="disabilities"
                name="disabilities"
                styles={multiSelectStyles}
            />

            <label className={styles.search_input_lbl} htmlFor="education">Education</label>
            { jobSearchState?.errors?.education && <p className={styles.error_msg}>{ jobSearchState.errors.education }</p> }
            <Select
                isMulti
                options={educationOptions}
                placeholder="Select education"
                closeMenuOnSelect={false}
                className={styles.search_input_react_select}
                inputId="education"
                name="education"
                styles={multiSelectStyles}
            />

            <h2 className={styles.search_area_h2}>Sort By:</h2>
            <div className={styles.search_input_radio_lbl}>
                <input type="radio" name="sort_by" id="sort_by_date_posted" value="sort_by_date_posted" defaultChecked />
                <label htmlFor="sort_by_date_posted">Date Posted</label>
            </div>
            <div className={styles.search_input_radio_lbl}>
                <input type="radio" name="sort_by" id="sort_by_salary" value="sort_by_salary" />
                <label htmlFor="sort_by_salary">Salary</label>
            </div>
            { jobSearchState?.errors?.sort_by && <p className={styles.error_msg}>{ jobSearchState.errors.sort_by }</p> }
            
            <button className={styles.search_btn} type="submit" disabled={pending}>Search</button>
        </form>
    );
}
