'use client'

import styles from './JobSearch.module.css'
import JobSearchForm from './JobSearchForm'
import { Suspense, useActionState } from "react"
import { getJobsBySearchFilters } from "../actions/job"
import JobSearchResults from './JobSearchResults'
import { MultiSelectOption } from '@/app/types/common'

interface JobSearchProps {
    cityOptions: MultiSelectOption[];
    disabilityOptions: MultiSelectOption[];
}

export default function JobSearch({ cityOptions, disabilityOptions }: JobSearchProps) {
    const [jobSearchState, jobSearchAction, pending] = useActionState(getJobsBySearchFilters, undefined);
    return (
        <div className={styles.job_search_area}>
            <div className={styles.search_area}>
                <div className={styles.search_area_header}>
                    <h1 className={styles.search_area_h1}>ADVANCED SEARCH</h1>
                </div>
                <div className={styles.search_area_body + ' ' + styles.search_area_body_bordered}>
                    <Suspense>
                        <JobSearchForm cityOptions={cityOptions} disabilityOptions={disabilityOptions} jobSearchState={jobSearchState} jobSearchAction={jobSearchAction} pending={pending} />
                    </Suspense>
                </div>
            </div>
            <div className={styles.search_area + ' ' + styles.search_results_area}>
                <div className={styles.search_area_header}>
                    <h1 className={styles.search_area_h1}>RESULTS</h1>
                </div>
                <div className={styles.search_results_area_body}>
                    <JobSearchResults jobSearchState={jobSearchState} pending={pending} />
                </div>
            </div>
        </div>
    )
}
