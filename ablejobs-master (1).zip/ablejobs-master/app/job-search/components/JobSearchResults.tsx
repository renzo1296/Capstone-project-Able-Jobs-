'use client'
import styles from './JobSearchResults.module.css'
import { JobSearchState } from '../definitions'
import JobCard from '@/app/home/components/JobCard'
import Image from 'next/image'

type Props = {
    jobSearchState: JobSearchState, 
    pending: boolean
}

export default function JobSearchResults({ jobSearchState, pending }: Props) {
    if (pending)
        return (
            <div className={styles.search_msg}>
                <Image 
                    src="/loading.gif"
                    alt="brain logo"
                    width={100}
                    height={100}
                    sizes="100vw"
                />
                <p>Searching...</p>
            </div>
        )
    if (jobSearchState?.jobs === undefined || jobSearchState?.jobs?.length === 0)
        return (
            <div className={styles.search_msg}>
                <p>No jobs found...</p>
            </div>
        )

    return (
        <div className={styles.job_search_area}>
            { jobSearchState?.jobs?.map( job => (
                <JobCard key={job.id} job={job}  />
            ))}
            
        </div>
    )
}
