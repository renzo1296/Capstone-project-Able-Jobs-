import TermsOfService from "../components/TermsOfService";

export default async function Profile() {
    return (
        <main>
            <TermsOfService />
        </main>
    )
}

