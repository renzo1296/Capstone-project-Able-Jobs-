'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
type CountdownProps = {
    duration: number
    redirectPath: string
}

export default function Countdown({ duration, redirectPath }: CountdownProps) {
    const [countdownState, setCountdownState] = useState(duration)
    const router = useRouter();

    useEffect(() => {
        setTimeout(() => setCountdownState(prev => prev-1), 1000);
    }, []);

    useEffect(() => {
        if (countdownState > 0)
            setTimeout(() => setCountdownState(countdownState - 1), 1000);
        else if (countdownState == 0) {
            router.push(redirectPath);
        }
    }, [countdownState, router, redirectPath]);
    
    return (
        <span> { countdownState } </span>
    )
}
