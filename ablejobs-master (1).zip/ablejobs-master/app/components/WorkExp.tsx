'use client';

import { useState, useEffect } from 'react';
import styles from './WorkExp.module.css';
import { WorkExpErrors, WorkExpItemSchema, WorkExpSchema } from './definitions';
import WorkExpItem from './WorkExpItem';

export interface WorkExpItemUI {
    id: string;
    data: WorkExpItemSchema;
}

interface WorkExpProps {
    initial_work_exp?: WorkExpSchema;
    disabled?: boolean;
    work_exp_errors?: WorkExpErrors;
    resetSignal?: number;
}

export default function WorkExp({ initial_work_exp = [], disabled=false, work_exp_errors, resetSignal }: WorkExpProps) {
    const [items, setItems] = useState<WorkExpItemUI[]>(
        initial_work_exp.map(item => ({
            id: String(crypto.randomUUID()),
            data: item
        }))
    );

    useEffect(() => {
        setItems(prev => prev.filter(item => !item.data.delete));
    }, [resetSignal]);

    const addItem = () => {
        setItems(prev => [
            ...prev,
            {
                id: crypto.randomUUID(),
                data: {
                    id: undefined,
                    delete: false,
                    company: "",
                    position: "",
                    from: "",
                    to: "",
                    is_present: false
                }
            }
        ]);
    };

    const deleteItem = (id: string) => {
        setItems(prev =>
            prev.flatMap(item => {
                if (item.id !== id) return [item];

                // If item has DB id → mark delete:true
                if (item.data.id) {
                    return [{
                        ...item,
                        data: { ...item.data, delete: true }
                    }];
                }

                // If new item → remove entirely
                return [];
            })
        );
    };

    return (
        <div className={styles.wrapper}>
            <h3 className={styles.title}>Work Experience</h3>

            {items.map((item, i) => (
                <WorkExpItem
                    key={item.id}
                    id={item.id}
                    index={i}
                    data={item.data}
                    disabled={disabled}
                    error={work_exp_errors?.work_exp_item_errors?.[i] ?? {}}
                    onDelete={() => deleteItem(item.id)}
                />
            ))}
            {work_exp_errors?.work_exp_errors && <p className={styles.error_msg}>{work_exp_errors.work_exp_errors.join(', ')}</p>}
            <button
                type="button"
                className={styles.addBtn}
                onClick={addItem}
                disabled={disabled}
            >
                + Add Work Experience
            </button>
        </div>
    );
}

