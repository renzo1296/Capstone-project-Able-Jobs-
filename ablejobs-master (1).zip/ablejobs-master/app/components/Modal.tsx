import { useEffect } from "react";
import styles from "./Modal.module.css"

export type ModalProps = {
    onNo: () => void
    children?: React.ReactNode
}

export default function Modal ({ onNo, children }: ModalProps) {
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === "Escape" || e.key === "Backspace") onNo();
        };
        window.addEventListener("keydown", handleKeyDown);
        return () => window.removeEventListener("keydown", handleKeyDown);
    }, [onNo]);

    return (
        <div className={styles.main_modal} onClick={onNo}>
            <div className={styles.modal_area} onClick={e => e.stopPropagation()}>
                {children}
            </div>
        </div>
    )
}

