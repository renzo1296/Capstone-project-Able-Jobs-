import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faFacebook, faInstagram, faTwitter } from '@fortawesome/free-brands-svg-icons'
import styles from "./Footer.module.css"
import Link from "next/link"
import NavLink from "./NavLink"

const Footer = () => {
    return (
        <footer className={styles.footer}>
            <ul className={styles.ul}>
                <li><Link href="privacy-policy">Privacy Policy</Link></li>
                <li><NavLink href="about-us">About Us</NavLink></li>
                <li><NavLink href="terms-of-service">Terms of Service</NavLink></li>
            </ul>
            <ul className={styles.ul + ' ' + styles.right}>
                <li className={styles.headerText}>Aim Progress and Recovery Physiotherapy Clinic</li>
                <li>
                    <b>Location:</b> Unit 6H, One Joroma Place Building, Congressional Ave., San Beda corner Brgy. Bahay Toro, Quezon City Medicare Plus Inc.
                </li>
                <li>
                    <b>Contact Numbers:</b> (02) 8697-2973 / (02) 6697-2920 / 0927-815-1873
                </li>
                <li>
                    <b>Email Address:</b> tmcantipolo@themedicalcity.com
                </li>
                <li>
                    <b>Operating Hours:</b> Monday to Friday, 8:00 AM – 5:00 PM
                </li>
                <div className={styles.socialLogos + ' ' + styles.right}>
                    <FontAwesomeIcon icon={faInstagram}
                        width={25}/>
                    <FontAwesomeIcon icon={faFacebook}
                        width={25}/>
                    <FontAwesomeIcon icon={faTwitter}
                        width={25}/>
                </div>
            </ul>
        </footer>
    )
}

export default Footer
