import { getSession, logout } from "@/app/utils/server/auth"
import styles from "./Navbar.module.css"
import NavLink from "./NavLink"
import { UserTypeEnum } from "../types/common";
import Image from "next/image"
import { faBars } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default async function Navbar() {
    const session = await getSession();

    return (
    <nav className={styles.nav_container}>
        <input type="checkbox" id="nav-toggle" className={styles.nav_toggle} />

        <label htmlFor="nav-toggle" className={styles.nav_burger}>
            <FontAwesomeIcon icon={faBars} width={35} />
        </label>

        <div className={styles.nav}>
            <div className={styles.nav_main_logo}>
                <Image 
                    src="/mainlogo.png"
                    alt="main logo"
                    fill
                    style={{ objectFit: "contain" }}
                />
            </div>
            <div className={styles.nav_logo_wide}>
                ABLEJOBS
            </div>
            <ul>
                <li><NavLink href="/home">Home</NavLink></li>
                <li><NavLink href="/job-search">Search</NavLink></li>
                { session === undefined ? 
                    <>
                        <li><NavLink href="/login">Login</NavLink></li>
                        <li><NavLink href="/sign-up">Sign Up</NavLink></li>
                    </>
                    :
                    <>
                        {
                            session.user_type === UserTypeEnum.Values.job_seeker ?
                            <>
                                <li><NavLink href="/profile">Profile</NavLink></li>
                                <li><NavLink href="/job/application">Applications</NavLink></li>
                            </>
                            :
                            <>
                                <li><NavLink href="/admin/dashboard">Dashboard</NavLink></li>
                                <li><NavLink href="/admin/job-seeker">Job Seeker</NavLink></li>
                                <li><NavLink href="/admin/add-job">Add Job</NavLink></li>
                                <li><NavLink href="/admin/add-disability">Add Disability</NavLink></li>
                                <li><NavLink href="/admin/add-city">Add City</NavLink></li>
                            </>
                        }
                        <div className={styles.navLogout}>
                            <div>Hi { session.username }! </div>
                            <button onClick={logout}>Logout</button>
                        </div>
                    </>
                }
            </ul>
        </div>
    </nav>
  )
}
