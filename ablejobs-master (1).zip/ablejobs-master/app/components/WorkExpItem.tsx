'use client';

import { useState } from 'react';
import styles from './WorkExpItem.module.css';
import { WorkExpItemErrors, WorkExpItemSchema } from './definitions';
import { getDateOnlyString } from '../utils/client/dateUtil';

interface WorkExpItemProps {
    id: string;
    index: number;
    data: WorkExpItemSchema;
    error?: WorkExpItemErrors;
    disabled?: boolean;
    onDelete: () => void;
}

export default function WorkExpItem({ id, index, data, onDelete, error, disabled=false }: WorkExpItemProps) {
    const [company, setCompany] = useState(data.company ?? "");
    const [position, setPosition] = useState(data.position ?? "");
    const [from, setFrom] = useState(data.from ?? "");
    const [to, setTo] = useState(data.to ?? "");
    const [isPresent, setIsPresent] = useState<boolean>(data.is_present ?? false);
    const [deleted, setDeleted] = useState<boolean>(data.delete ?? false);

    const toggleDelete = () => {
        onDelete();
        setDeleted(prev => !prev);
    }

    return (
        <div className={`${styles.item} ${deleted ? styles.deleted : ''}`}>
            {/* Hidden metadata */}
            <input type="hidden" name={`work_exp[${index}][id]`} value={data.id ?? ''} />
            <input type="hidden" name={`work_exp[${index}][delete]`} value={deleted ? "true" : "false"} />

            <button
                type="button"
                className={`${styles.deleteBtn} ${deleted ? styles.undoBtn : ''}`}
                onClick={toggleDelete}
                disabled={disabled}
                aria-label="Delete or undo work experience entry"
            >
                {deleted ? "Undo" : "✕"}
            </button>

            <label className={styles.field}>
                Company
                {error?.company && <p className={styles.error_msg}>{error.company.join(', ')}</p>}
                <input type="text" name={`work_exp[${index}][company]`} disabled={disabled || deleted} value={company} onChange={e => setCompany(e.target.value)} />
            </label>

            <label className={styles.field}>
                Position
                {error?.position && <p className={styles.error_msg}>{error.position.join(', ')}</p>}
                <input type="text" name={`work_exp[${index}][position]`} disabled={disabled || deleted} value={position} onChange={e => setPosition(e.target.value)} />
            </label>

            <label className={`${styles.field} ${styles.full}`}>
                From
                {error?.from && <p className={styles.error_msg}>{error.from.join(', ')}</p>}
                <input type="date" name={`work_exp[${index}][from]`} disabled={disabled || deleted} value={getDateOnlyString(from)} onChange={e => setFrom(e.target.value)} />
            </label>

            <label className={`${styles.field} ${styles.full}`}>
                To
                {error?.to && <p className={styles.error_msg}>{error.to.join(', ')}</p>}
                <input type="date" name={`work_exp[${index}][to]`} disabled={disabled || deleted || isPresent} value={getDateOnlyString(to)} onChange={e => setTo(e.target.value)} />
            </label>

            <label className={`${styles.present} ${styles.full}`}>
                <input type="checkbox" name={`work_exp[${index}][is_present]`} disabled={disabled || deleted} checked={isPresent} onChange={e => setIsPresent(e.target.checked)} />
                {error?.is_present && <p className={styles.error_msg}>{error.is_present.join(', ')}</p>}
                This is my current job
            </label>
        </div>
    );
}

