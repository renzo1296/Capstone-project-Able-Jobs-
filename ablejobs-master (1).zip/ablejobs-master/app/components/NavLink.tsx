'use client'

import Link from 'next/link'
import React from 'react'
import styles from './NavLink.module.css'
import { usePathname } from 'next/navigation'

type NavLinkProps = {
    children: React.ReactNode
    className?: string
    href: string
}

export default function NavLink({ children, className, href }: NavLinkProps) {
    const pathName = usePathname()

    return (
        <Link 
            href={href}
            className={className + " " + (pathName.endsWith(href) ? styles.active : '')}>
            {children}
        </Link>
    )
}
