import Modal, { ModalProps } from "./Modal";
import styles from "./ConfirmationModal.module.css";
import { useEffect, useRef, useState } from "react";

type ConfirmationModaProps = ModalProps & {
    message?: string;
    yesText?: string;
    noText?: string;
    onYes: () => void;
};

export default function ConfirmationModal({
    message = "Are you sure you want to proceed?",
    yesText = "Yes",
    noText = "Cancel",
    children,
    onYes,
    onNo,
}: ConfirmationModaProps) {
    const childrenRef = useRef<HTMLDivElement>(null);
    const [isReachedBottom, setIsReachedBottom ] = useState(true);
    const bottomEpsilon = 3;

    useEffect(() => {
        const el = childrenRef.current;
        if (!el) return;
        setIsReachedBottom(Math.abs(el.scrollHeight - el.clientHeight) <= bottomEpsilon);
    }, []);

    function handleScroll(e: React.UIEvent<HTMLDivElement>) {
        const el = e.currentTarget;
        setIsReachedBottom(Math.abs(el.scrollHeight - Math.round(el.scrollTop) - el.clientHeight) <= bottomEpsilon);
    }
    
    return (
        <Modal onNo={onNo}>
            <div className={styles.container}>
                <p className={styles.message}>{message}</p>
                <div ref={childrenRef} onScroll={handleScroll} className={styles.children_wrapper}>
                    {children}
                </div>
                <div className={styles.buttonRow}>
                    <button className={`${styles.button} ${styles.buttonYes}`} disabled={!isReachedBottom} onClick={onYes}>
                        {yesText}
                    </button>
                    <button className={`${styles.button} ${styles.buttonNo}`} disabled={!isReachedBottom} onClick={onNo}>
                        {noText}
                    </button>
                </div>
            </div>
        </Modal>
    );
}

