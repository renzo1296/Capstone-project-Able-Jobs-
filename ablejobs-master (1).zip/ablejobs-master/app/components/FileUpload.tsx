'use client'

import { useState } from "react"
import { createPortal } from "react-dom"
import PreviewModal from "./PreviewModal"
import styles from "./FileUpload.module.css";
import { ACCEPTED_DOC_TYPES, ACCEPTED_IMAGE_TYPES } from "../types/common";

export enum FileType {
  Image = "image",
  Document = "document",
}

export type FileUploadProps = {
    id: string
    name: string
    labelText: string
    errorText?: string[]
    existingFileSrc?: string
    type?: FileType
    disabled?: boolean
    children?: React.ReactNode
}

export default function FileUpload ({ 
    id, 
    name, 
    labelText, 
    errorText,
    existingFileSrc,
    type = FileType.Image,
    disabled = false}: FileUploadProps) {
    const [fileUploadSrc, setFileUploadSrc] = useState('')
    const [currentFileSrc, setCurrentFileSrc] = useState('')
    const [isPreviewing, setIsPreviewing] = useState(false)

    const handleUploadFile = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;
        setFileUploadSrc(URL.createObjectURL(file));
    }
    return (
        <div className={styles.container}>
            <div className={styles.labelRow}>
                <label htmlFor={id}>{labelText}</label>
                {
                    <div className={styles.previewContainer}>
                        { existingFileSrc &&
                            <button
                                type="button"
                                onClick={() => { 
                                    setCurrentFileSrc(existingFileSrc); 
                                    setIsPreviewing(true)
                                }}
                                className={styles.button + ' ' + styles.buttonExisting}
                            >
                                Current
                            </button>
                        }
                        { fileUploadSrc && 
                            <button
                                type="button"
                                onClick={() => { 
                                    setCurrentFileSrc(fileUploadSrc); 
                                    setIsPreviewing(true)
                                }}
                                className={styles.button}
                            >
                                Preview
                            </button>
                        }
                    </div>
                }
            </div>
            { errorText && <p className={styles.error_msg}>{ errorText }</p> }

            <input
                type="file"
                id={id}
                name={name}
                onChange={handleUploadFile}
                accept={type === FileType.Image ? ACCEPTED_IMAGE_TYPES.join(",") : ACCEPTED_DOC_TYPES.join(",")}
                className={styles.input}
                disabled={disabled}
            />

            {isPreviewing &&
                createPortal(
                    <PreviewModal onNo={() => setIsPreviewing(false)}>
                        { 
                            type === FileType.Image && 
                            <img 
                                src={currentFileSrc} 
                                alt="preview" 
                                className={styles.previewImage} 
                            />
                        }
                        {
                            type === FileType.Document &&
                            <div className={styles.previewDoc}>
                                <embed 
                                    src={currentFileSrc} 
                                    type="application/pdf"
                                    />
                            </div>
                        }
                    </PreviewModal>,
                    globalThis.document.body
            )}
        </div>
    )
}

