import Modal from "./Modal";
import styles from "./PreviewModal.module.css";

export type PreviewModalProps = {
    onNo: () => void;
    children?: React.ReactNode;
};

export default function PreviewModal({ onNo, children }: PreviewModalProps) {
    return (
        <Modal onNo={onNo}>
            <div className={styles.container}>
                {children}
            </div>
        </Modal>
    );
}

