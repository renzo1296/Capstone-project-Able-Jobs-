'use client'

import { useState, useEffect } from 'react'
import styles from './AccessibilitySettings.module.css'

export default function AccessibilitySettings () {
    const [openedState, setOpenedState] = useState(false);
    const [fontSize, setFontSize] = useState(16);
    const [theme, setTheme] = useState<'light'|'dark'>('light');

    // Load saved theme on component mount
    useEffect(() => {
        const savedTheme = localStorage.getItem('theme') || 'light';
        setTheme(savedTheme as 'light' | 'dark');
        document.documentElement.setAttribute('data-theme', savedTheme);
    }, []);

    const handleIncreaseFontSize = (offset: number) => {
        const newFontSize = fontSize + offset;
        document.documentElement.style.fontSize = `${newFontSize}px`;
        setFontSize(newFontSize);
    }

    const toggleTheme = () => {
        const newTheme = theme === 'light' ? 'dark' : 'light';
        setTheme(newTheme);
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
    }

    return (
        <>
            <div role={'button'} 
                onClick={() => setOpenedState(prevState => !prevState)} 
                className={styles.container}>
            </div>
            <div className={styles.settings_container + (openedState ? '' : ' ' + styles.active)}>
                <p className={styles.accessibility_option_lbl}>
                    Increase/Decrease Font
                </p>
                <div className={styles.font_modify_container}>
                    <button className={styles.btn} onClick={() => handleIncreaseFontSize(1)}>+</button>
                    <button className={styles.btn} onClick={() => handleIncreaseFontSize(-1)}>-</button>
                </div>
                <div className={styles.theme_toggle_container}>
                    <span className={styles.theme_label}>Dark Mode</span>
                    <label className={styles.switch}>
                        <input type="checkbox" checked={theme === 'dark'} onChange={toggleTheme} />
                        <span className={styles.slider}></span>
                    </label>
                </div>
            </div>
        </>
    )
}
