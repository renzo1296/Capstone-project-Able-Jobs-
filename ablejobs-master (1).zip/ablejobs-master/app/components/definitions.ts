import { z, ZodIssue } from "zod";

export type WorkExpItemErrors = {
    company?: string[]
    position?: string[]
    from?: string[]
    to?: string[]
    is_present?: string[]
    work_exp_item_errors?: string[]
}

export type WorkExpErrors = {
    work_exp_errors?: string[]
    work_exp_item_errors?: Record<number, WorkExpItemErrors>
}

export type FlattenedErrors = Record<string, string[]>;
export function flattenNonArrayErrors(errors: ZodIssue[], arrayFields: string[] = []): FlattenedErrors {
    const out: FlattenedErrors = {};

    for (const err of errors) {
        const [field, index, subfield] = err.path;

        // skip array fields
        if (field && !arrayFields.includes(field as string)) {
            if (!out[field as string]) out[field as string] = [];
            out[field as string].push(err.message);
        }
    }

    return out;
}

export function getWorkExpErrors(errors: ZodIssue[]): WorkExpErrors {
    const out: WorkExpErrors = {
        work_exp_errors: [],
        work_exp_item_errors: []
    };

    for (const err of errors) {
        const [field, index, subfield] = err.path;

        if (field === "work_exp") {
            if (typeof index === "number" && typeof subfield === "string") {
                if (!out.work_exp_item_errors![index]) out.work_exp_item_errors![index] = {};
                if (!out.work_exp_item_errors![index][subfield as keyof WorkExpItemErrors]) 
                    out.work_exp_item_errors![index][subfield as keyof WorkExpItemErrors] = [];
                out.work_exp_item_errors![index][subfield as keyof WorkExpItemErrors]?.push(err.message);
            }
            if (index === "work_exp_errors") {
                out.work_exp_errors!.push(err.message);
            }
        }
    }

    return out;
}

export const WorkExpItemSchema = z.object({
    id: z.string().optional(),
    delete: z.string().default("false").transform(val => val === "true"),

    // conditional pattern: allow empty string / undefined, otherwise enforce validation
    company: z.string().refine(val => val === "" || val === undefined).or(
        z.string().min(1, { message: "Company is required" })
    ),
    position: z.string().refine(val => val === "" || val === undefined).or(
        z.string().min(2, { message: "Position is required" })
    ),
    from: z.string().refine(val => val === "" || val === undefined).or(
        z.string().refine(val => !isNaN(Date.parse(val)), {
            message: "From date is required and must be valid",
        })
    ),
    to: z.string().optional(),
    is_present: z.boolean().optional(),
}).superRefine((item, ctx) => {
    if (item.delete) {
        if (!item.id) {
            ctx.addIssue({
                code: "custom",
                message: "Cannot delete item without an id",
                path: ["work_exp_item_errors"],
            });
        }
        // skip all other validations
        return;
    }

    // require other fields (except id) when delete=false
    if (!item.company || item.company.trim() === "") {
        ctx.addIssue({
            code: "custom",
            message: "Company is required",
            path: ["company"],
        });
    }

    if (!item.position || item.position.trim() === "") {
        ctx.addIssue({
            code: "custom",
            message: "Position is required",
            path: ["position"],
        });
    }

    if (!item.from || isNaN(Date.parse(item.from))) {
        ctx.addIssue({
            code: "custom",
            message: "From date is required and must be valid",
            path: ["from"],
        });
    }

    if (!item.is_present) {
        // validate `to` only if is_present is false / undefined
        if (!item.to) {
            ctx.addIssue({
                code: "custom",
                message: "'To' date is required if this is not current job",
                path: ["to"],
            });
        } else if (new Date(item.from) > new Date(item.to!)) {
            ctx.addIssue({
                code: "custom",
                message: "'From' date must be before 'To' date",
                path: ["from"],
            });
        }
    }
});
export type WorkExpItemSchema = z.infer<typeof WorkExpItemSchema>;

export const WorkExpSchema = z.array(WorkExpItemSchema)
    .superRefine((items, ctx) => {
        // Only one current job allowed
        const presentCount = items.filter(i => i.is_present).length;
        if (presentCount > 1) {
            ctx.addIssue({
                code: "custom",
                message: "Only one current job can be marked as present",
                path: ["work_exp_errors"],
            });
        }
    });
export type WorkExpSchema = z.infer<typeof WorkExpSchema>;
