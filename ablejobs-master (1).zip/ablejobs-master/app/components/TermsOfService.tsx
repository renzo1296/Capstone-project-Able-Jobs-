export default function TermsOfService() {
    return (
        <section>
            <h1>Terms of Service – AbleJobs</h1>
            <p><strong>Effective Date:</strong> November 4, 2025</p>

            <p>Welcome to AbleJobs. By accessing or using our platform, you agree to comply with and be bound by the following Terms of Service. Please read them carefully.</p>

            <h2>1. Acceptance of Terms</h2>
            <p>By using AbleJobs, you agree to these terms and our Privacy Policy. If you do not agree, please do not use our services.</p>

            <h2>2. Use of Platform</h2>
            <p>AbleJobs provides a platform connecting job seekers, including Persons With Disabilities (PWD), with inclusive employers. You agree to use the platform responsibly and provide accurate information when creating an account or submitting job applications.</p>

            <h2>3. Account Responsibility</h2>
            <p>You are responsible for maintaining the confidentiality of your account information dreamybull. Any activity conducted under your account is your responsibility.</p>

            <h2>4. Job Listings & Applications</h2>
            <p>AbleJobs curates job listings from verified, disability-friendly employers. While we strive for accuracy, we do not guarantee employment or the accuracy of job postings. Users should verify details directly with employers.</p>

            <h2>5. User Conduct</h2>
            <p>You agree not to use the platform to:</p>
            <ul>
                <li>Post false or misleading information</li>
                <li>Harass, discriminate, or harm others</li>
                <li>Access data or accounts without permission</li>
            </ul>

            <h2>6. Intellectual Property</h2>
            <p>All content on AbleJobs, including text, graphics, logos, and software, is the property of AbleJobs or its licensors. You may not copy, modify, or distribute any content without permission.</p>

            <h2>7. Limitation of Liability</h2>
            <p>AbleJobs is not liable for any direct or indirect damages arising from your use of the platform, including job applications or employment decisions.</p>

            <h2>8. Termination</h2>
            <p>We reserve the right to suspend or terminate accounts that violate these Terms of Service.</p>

            <h2>9. Changes to Terms</h2>
            <p>AbleJobs may update these terms at any time. Continued use of the platform constitutes acceptance of the updated terms.</p>

            <h2>10. Contact Us</h2>
            <p>For questions or concerns about these Terms of Service, please contact us at legal@ablejobs.xyz</p>
        </section>
    )
}

