import { z } from "zod";
import { isFileSelected } from "@/app/utils/server/helpers";
import { 
    SexEnum, 
    EducationEnum, 
    MAX_IMAGE_SIZE, 
    MAX_DOC_SIZE, 
    ACCEPTED_IMAGE_TYPES, 
    ACCEPTED_DOC_TYPES } from "@/app/types/common"
import { SignUpState, SignUpStateErrors } from "../sign-up/definitions"
import { WorkExpSchema } from "../components/definitions";
import { makeDisabilitySchema } from "../job-search/definitions";

export type UpdateState = 
    SignUpState & {
        errors?: SignUpStateErrors & { 
            is_password_change?: string[] 
            current_password?: string[]
        }
    } | undefined

const ImageType = z.instanceof(File)
    .optional()
    .refine(file => !isFileSelected(file) || file!.size <= MAX_IMAGE_SIZE,
        {message: "Max image size is 5MB."})
    .refine(file => !isFileSelected(file) || ACCEPTED_IMAGE_TYPES.includes(file!.type),
        ".jpg, .jpeg, .png, .webp, files are accepted only");

const DocType = z.instanceof(File)
    .optional()
    .refine(file => !isFileSelected(file) || file!.size <= MAX_DOC_SIZE,
        {message: "Max document size is 10MB."})
    .refine(file => !isFileSelected(file) || ACCEPTED_DOC_TYPES.includes(file!.type),
        ".pdf files are accepted only");

export async function makeUpdateFormSchema() {
    return z.object({
        firstname: z
            .string()
            .min(1, { message: 'First name is required.' })
            .max(50, { message: 'First name must be at most 50 characters long.'})
            .trim(),
        lastname: z
            .string()
            .min(1, { message: 'Last name is required.'})
            .max(50, { message: 'Last name must be at most 50 characters long.'})
            .trim(),
        sex: SexEnum,
        birthdate: z.string().date('Must be in YYYY-MM-DD format'),
        address: z
            .string()
            .max(255, {message: 'Address must be at most 255 characters long.'})
            .trim(),
        phone_number: z
            .string()
            .max(15, { message: 'Phone number must be at most 15 characters long.'})
            .trim(),
        username: z
            .string()
            .min(1, { message: 'Username is required.'})
            .max(50, { message: 'Username must be at most 50 characters long.'})
            .trim(),
        email: z
            .string()
            .email({ message: 'Enter a valid email'})
            .max(320, { message: 'Email must be at most 320 characters long.'})
            .trim(),
        change_password_chkbx: z.string().optional(),
        current_password: z
            .string()
            .trim()
            .min(1, { message: 'Must enter current password.' }),
        password: z
            .string()
            .trim()
            .optional(),
        confirm_password: z.string().optional(),
        disabilities: z.array(await makeDisabilitySchema())
            .transform(disabilities => disabilities.filter(disability => disability !== '')),
        work_exp: WorkExpSchema,
        profile_pic: ImageType,
        pwd_id_pic: ImageType,
        resume_file: DocType,
        government_issued_id_pic: ImageType,
        nbi_clearance: DocType,
        tor: DocType,
        pwd_id_number: z
            .string()
            .min(1, { message: 'PWD ID Number is required.'})
            .max(50, { message: 'PWD ID Number must be at most 50 characters long.'}),
        senior_id_number: z.string(),
        sss: z.string(),
        tin: z.string(),
        philhealth: z.string(),
        education: EducationEnum
    }).superRefine(({ change_password_chkbx, password, confirm_password}, ctx) => {
        if (change_password_chkbx === 'on') {
            if (password === undefined || password.length < 8) {
                ctx.addIssue({
                    code: 'custom',
                    message: "Password must be at least 8 characters long.",
                    path: ['password']
                });
            }
            if (password!.length > 255 ) {
                ctx.addIssue({
                    code: 'custom',
                    message: "Password must be at most 255 characters long.",
                    path: ['password']
                });
            }
            if (password !== confirm_password) {
                ctx.addIssue({
                    code: "custom",
                    message: "The passwords did not match",
                    path: ['confirm_password']
                });
            }
        }
    });
}

export type UpdateFormSchema = z.infer<ReturnType<typeof makeUpdateFormSchema> extends Promise<infer S> ? S : never>;
