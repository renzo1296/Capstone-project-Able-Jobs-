'use server'

import path from "path";
import { makeUpdateFormSchema, UpdateFormSchema, UpdateState } from "../definitions";
import pool from "@/app/lib/db";
import { createSession, deleteSession, getSession } from "@/app/utils/server/auth";
import { isFileSelected } from "@/app/utils/server/helpers";
import { BUCKET_NAME, CreateBucket, getUserDir, ListBucketFiles, MoveFolder, RemoveFiles, UploadFile } from "@/app/lib/supabase";
import { UserTypeEnum } from "@/app/types/common";
import { parseWorkExp } from "@/app/utils/server/formDataHelper";
import { flattenNonArrayErrors, getWorkExpErrors, WorkExpSchema } from "@/app/components/definitions";
import { PoolClient } from "pg";
import { handleFileSubmissions } from "@/app/utils/server/userHelper";

export async function update(prevState: UpdateState, formData: FormData, id: number): Promise<UpdateState> {
    const session = await getSession();
    if (!session) return prevState;

    const entries = Object.fromEntries(formData);

    // get old user data
    const query2 = "SELECT * FROM user_ WHERE id=$1";
    const values2 = [id];
    const oldData = (await pool.query(query2, values2)).rows[0];

    // no need to type job-seeker's password if an admin is updating
    const isAdmin = session.user_type === UserTypeEnum.Values.admin;
    if (isAdmin) {
        entries.current_password = oldData.password;
    }

    // no need to type password if oauth sign up and first time changing password
    const isOAuthFirstReset = !oldData.oauth_reset_password_done;
    if (isOAuthFirstReset) {
        entries.current_password = oldData.password;
    }

    // Parse workExp dynamically
    const workExpArray = parseWorkExp(formData);
    console.log("Parsed workExp in update:", workExpArray);

    const updateFormSchema = await makeUpdateFormSchema();
    const validatedEntries = updateFormSchema.safeParse({
        ...entries,
        work_exp: workExpArray,
        disabilities: formData.getAll('disabilities')
    });
    if (!validatedEntries.success) {
        console.log("UPDATE guys it didn't success: ", validatedEntries.error.flatten().fieldErrors)
        console.log("UPDATE guys it didn't success not flattened: ", validatedEntries.error)
        const unflattenedErrors = validatedEntries.error.issues;
        console.log("UPDATE guys it issueesss: ", validatedEntries.error.issues);

        const fieldErrors = flattenNonArrayErrors(unflattenedErrors, ["work_exp"]);
        const workExpErrors = getWorkExpErrors(unflattenedErrors);
        console.log("UPDATE da workexp errors...: ", workExpErrors);
        return {
            errors: {
                ...fieldErrors,
                work_exp: workExpErrors
            }
        }
    }
    console.log("UPDATE guys it got validated sucess omg: ", validatedEntries.data);

    // if user signed up via OAuth,
    // but user is not trying to change password,
    // return error (enforce changing of password in this case)
    if (isOAuthFirstReset && validatedEntries.data.change_password_chkbx !== "on")
        return { errors: { current_password: ["If signed up via OAuth, must change password on first update!"] } };
 
    // check first if password is correct 
    // (skip this check if: 
    // - it's an admin updating
    // - user signed up via OAuth and first time resetting password)
    if (!isAdmin && !isOAuthFirstReset && oldData.password !== validatedEntries.data.current_password)
        return { errors: { current_password: ["Incorrect password!"] } };
    
    // check if user trynna change username and username already exists
    const query3 = "SELECT * FROM user_ WHERE username=$1";
    const values3 = [validatedEntries.data.username];
    const res3 = await pool.query(query3, values3);
    if (res3.rowCount != 0 && res3.rows[0].username !== oldData.username) {
        return { errors: { username: ["Username already exists!"]} };
    }

    // create bucket if doesn't exist
    await CreateBucket(BUCKET_NAME);

    // if changing username, must rename its old storage folder
    // which was named on user's old username
    const userDir = getUserDir(validatedEntries.data.username);
    const oldUserDir = getUserDir(oldData.username);
    await MoveFolder(oldUserDir, userDir);

    await handleFileSubmissions(validatedEntries.data);

    const query =  `UPDATE job_seeker_
                    SET
                        firstname = $1,
                        lastname = $2,
                        sex = $3,
                        birthdate = $4,
                        address = $5,
                        phone_number = $6,
                        pwd_id_number = $7,
                        senior_id_number = $8,
                        sss = $9,
                        tin = $10,
                        philhealth = $11,
                        education = $12
                    WHERE
                        user_id = $13`
    const values = [
                        validatedEntries.data.firstname, 
                        validatedEntries.data.lastname, 
                        validatedEntries.data.sex, 
                        validatedEntries.data.birthdate, 
                        validatedEntries.data.address, 
                        validatedEntries.data.phone_number, 
                        validatedEntries.data.pwd_id_number, 
                        validatedEntries.data.senior_id_number, 
                        validatedEntries.data.sss, 
                        validatedEntries.data.tin, 
                        validatedEntries.data.philhealth, 
                        validatedEntries.data.education,
                        id
    ];

    const query4 =  `UPDATE user_
                    SET
                        username = $1,
                        email = $2,
                        password = $3,
                        oauth_reset_password_done = $4
                    WHERE
                        id = $5`
    const values4 = [
                        validatedEntries.data.username, 
                        validatedEntries.data.email, 
                        validatedEntries.data.change_password_chkbx === "on" ? validatedEntries.data.password : validatedEntries.data.current_password,
                        true,
                        id
    ];

    const client = await pool.connect();

    try {
        await client.query('BEGIN');

        await client.query(query, values);
        await client.query(query4, values4);

        // update workexp
        await saveWorkExperience(client, validatedEntries.data.work_exp, id);

        // update disabilities
        await saveDisabilities(client, validatedEntries.data.disabilities, id);

        await client.query('COMMIT');

        // update session (don't do this if it's an admin editing!!)
        const isUpdatingUsername = validatedEntries.data.username !== oldData.username;
        if (!isAdmin && isUpdatingUsername) {
            await deleteSession();
            await createSession(oldData.id, validatedEntries.data.username, oldData.user_type);
        }
    }
    catch(error: unknown) {
        console.error('Context:', "Database update error");
        if (error instanceof Error) {
            console.error('Caught error:', error.message);
            return {
                message: "Database update error: " + error.message,
                isErrorMessage: true
            }
        } 
        else {
            console.error('Unknown error:', error);
            return {
                message: "Database update unknown error: " + error,
                isErrorMessage: true
            }
        }
    }
    finally {
        client.release();
    }

    return  {
        message: "Update successful!"
    }
}

async function saveWorkExperience(
    client: PoolClient,
    workExpItems: WorkExpSchema,
    userId: Number 
) {
    for (const item of workExpItems) {
        const hasId = item.id && item.id !== "";

        // DELETE
        if (hasId && item.delete) {
            await client.query(
                `DELETE FROM work_exp_ WHERE id = $1 AND user_id = $2`,
                [item.id, userId]
            );
            continue;
        }

        // UPDATE
        if (hasId && !item.delete) {
            await client.query(
                `
                UPDATE work_exp_
                SET company = $1,
                    position = $2,
                    from_date = $3,
                    to_date = $4,
                    is_present = $5
                WHERE id = $6 AND user_id = $7
                `,
                [
                    item.company,
                    item.position,
                    item.from,
                    item.is_present ? null : item.to,
                    item.is_present ?? false,
                    item.id,
                    userId
                ]
            );
            continue;
        }

        // INSERT
        if (!hasId && !item.delete) {
            await client.query(
                `
                INSERT INTO work_exp_ (
                    user_id, company, position,
                    from_date, to_date, is_present
                )
                VALUES ($1, $2, $3, $4, $5, $6)
                `,
                [
                    userId,
                    item.company,
                    item.position,
                    item.from,
                    item.is_present ? null : item.to,
                    item.is_present ?? false
                ]
            );
        }

        // ignore: no-id + delete=true
    }
}

async function saveDisabilities(
    client: PoolClient,
    selectedDisabilities: string[],
    userId: number
) {
    // Fetch current disabilities for user
    const currentRes = await client.query<{ disability_type: string }>(
        `SELECT disability_type FROM job_seeker_disability_type_ WHERE user_id = $1`,
        [userId]
    );
    const currentDisabilities = currentRes.rows.map(r => r.disability_type);

    // Compute deletions and insertions
    const toDelete = currentDisabilities.filter(d => !selectedDisabilities.includes(d));
    const toInsert = selectedDisabilities.filter(d => !currentDisabilities.includes(d));

    // Delete removed
    for (const d of toDelete) {
        await client.query(
            `DELETE FROM job_seeker_disability_type_ WHERE user_id = $1 AND disability_type = $2`,
            [userId, d]
        );
    }

    // Insert new
    for (const d of toInsert) {
        await client.query(
            `INSERT INTO job_seeker_disability_type_ (user_id, disability_type) VALUES ($1, $2)`,
            [userId, d]
        );
    }
}

