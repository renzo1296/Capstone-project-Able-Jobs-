'use server'

import pool from "@/app/lib/db";
import { getUserDir, ListBucketFiles, RemoveFiles } from "@/app/lib/supabase";
import { UserTypeEnum } from "@/app/types/common";
import { getSession, logout } from "@/app/utils/server/auth";
import { redirect } from "next/navigation";

export async function deleteAccount(id: number): Promise<void> {
    const session = await getSession();
    if (!session) return;

    const query1 = "SELECT * FROM user_ WHERE id=$1";
    const values = [id];
    const userDataRes = await pool.query(query1, values);
    if (userDataRes.rowCount != 1)
        return;
    const userData = userDataRes.rows[0];

    const query3 = "DELETE FROM job_application_ WHERE user_id=$1";
    await pool.query(query3, values);

    const query2 = "DELETE FROM user_ WHERE id=$1";
    await pool.query(query2, values);

    // delete user files in storage
    const userDir = getUserDir(userData.username);
    const currentUserFiles = await ListBucketFiles(userDir);
    await RemoveFiles(currentUserFiles.map(file => `${userDir}/${file.name}`));

    if (session.user_type === UserTypeEnum.Values.job_seeker)
        await logout();
    if (session.user_type === UserTypeEnum.Values.admin)
        redirect('/admin/job-seeker');
}
