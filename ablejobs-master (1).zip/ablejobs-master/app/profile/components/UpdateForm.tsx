'use client'

import styles from "./UpdateForm.module.css"
import { useState, useEffect, startTransition, useActionState, useRef } from "react"
import { update } from "../action/update"
import { deleteAccount } from "@/app/profile/action/delete"
import { createPortal } from "react-dom"
import { MultiSelectOption, SexEnum, User } from "@/app/types/common"
import { UpdateState } from "../definitions"
import Image from 'next/image'
import ConfirmationModal from "@/app/components/ConfirmationModal"
import FileUpload, { FileType } from "@/app/components/FileUpload"
import WorkExp from "@/app/components/WorkExp"
import { getDateOnlyString } from "@/app/utils/client/dateUtil"
import Select from "react-select"
import { useTheme } from "@/app/context/ThemeContext"
import { getMultiSelectStyles } from "@/app/types/styles"

interface ProfileProps {
    profilePicUrlSrc: string;
    pwdIdPicUrlSrc: string;
    resumeFileUrlSrc: string;
    governmentIssuedIdPicUrlSrc: string;
    nbiClearanceUrlSrc: string;
    torUrlSrc: string;
    profileData: User;
    disabilityOptions: MultiSelectOption[];
    isAdmin?: boolean;
}

export default function UpdateForm ( { 
    profilePicUrlSrc, 
    profileData, 
    disabilityOptions,
    pwdIdPicUrlSrc,
    resumeFileUrlSrc,
    governmentIssuedIdPicUrlSrc,
    nbiClearanceUrlSrc,
    torUrlSrc,
    isAdmin = false }: ProfileProps ) {
    const { theme } = useTheme();
    const isDarkMode = theme === 'dark';
    const multiSelectStyles = getMultiSelectStyles(isDarkMode);

    const updateWithId = async (prevState: UpdateState, formData: FormData) => {
        return await update(prevState, formData, profileData.id);
    };

    const [updateState, updateAction, pending] = useActionState(updateWithId, undefined)
    const [selectedSex, setSelectedSex] = useState(profileData.sex)
    const [isChangePassword, setIsChangePassword] = useState(false)
    const [currentPassword, setCurrentPassword] = useState("")
    const [newPassword, setNewPassword] = useState("")
    const [confirmPassword, setConfirmPassword] = useState("")
    const [isDeleting, setIsDeleting] = useState(false)
    const [isUpdating, setIsUpdating] = useState(false)
    const [isEditing, setIsEditing] = useState(false)
    const [workExpResetSignal, setWorkExpResetSignal] = useState(0);

    const formRef = useRef<HTMLFormElement>(null);

    // console.log("da bday converted", new Date(profileData?.birthdate)?.toISOString()?.split("T")[0])
    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
        const formData = new FormData(e.currentTarget);
        startTransition(() => updateAction(formData))
    };

    const handleSelectedSexChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setSelectedSex(event.target.value as SexEnum);
    }

    const handleDelete = async () => {
        setIsDeleting(deleting => !deleting)
    }

    const birthDate = getDateOnlyString(profileData.birthdate);

    useEffect(() => {
        if (updateState?.message && !updateState?.isErrorMessage) {
            setWorkExpResetSignal(s => s + 1);
        }
    }, [updateState]);

    return (
    <form ref={formRef} onSubmit={handleSubmit} className={styles.update_form}>
        {
            isDeleting && 
            createPortal(
                <ConfirmationModal 
                    onNo={() => setIsDeleting(false)}
                    onYes={() => deleteAccount(profileData.id)} 
                />, globalThis.document.body)
        }
        {
            isUpdating && 
            createPortal(
                <ConfirmationModal 
                    onNo={() => setIsUpdating(false)}
                    onYes={() => {
                        formRef.current?.requestSubmit();
                        setIsUpdating(false);
                    }} 
                />, globalThis.document.body)
        }
        <div className={styles.profile_area}>
            <Image 
                src={profilePicUrlSrc} 
                alt="My Profile Pic" 
                width={500} 
                height={500} 
                layout={'intrinsic'}
                className={styles.profile_img}
            /><br />
            <FileUpload id="profile_pic" name="profile_pic" labelText="Update Picture" errorText={updateState?.errors?.profile_pic} existingFileSrc={profilePicUrlSrc} disabled={!isEditing} />

            <FileUpload id="pwd_id_pic" name="pwd_id_pic" labelText="Upload PWD ID" errorText={updateState?.errors?.pwd_id_pic} existingFileSrc={pwdIdPicUrlSrc} disabled={!isEditing} />

            <FileUpload id="resume_file" name="resume_file" labelText="Upload Resume" errorText={updateState?.errors?.resume_file} type={FileType.Document} existingFileSrc={resumeFileUrlSrc} disabled={!isEditing} />

            <FileUpload id="government_issued_id_pic" name="government_issued_id_pic" labelText="Upload Government-Issued Id" errorText={updateState?.errors?.government_issued_id_pic} type={FileType.Image} existingFileSrc={governmentIssuedIdPicUrlSrc} disabled={!isEditing} />

            <FileUpload id="nbi_clearance" name="nbi_clearance" labelText="Upload NBI Clearance" errorText={updateState?.errors?.nbi_clearance} type={FileType.Document} existingFileSrc={nbiClearanceUrlSrc} disabled={!isEditing} />

            <FileUpload id="tor" name="tor" labelText="Upload Transcript of Records (TOR)" errorText={updateState?.errors?.tor} type={FileType.Document} existingFileSrc={torUrlSrc} disabled={!isEditing} />

            <div className={styles.chkbox_w_label}>
                <input type="checkbox" onChange={e => setIsEditing(e.target.checked)} checked={isEditing} id="edit_chkbx" name="edit_chkbx" />
                <label htmlFor="edit_chkbx">Edit</label><br />
            </div>
            <div className={styles.chkbox_w_label}>
                <input type="checkbox" disabled={!isEditing} onChange={e => setIsChangePassword(e.target.checked)} checked={isChangePassword} id="change_password_chkbx" name="change_password_chkbx" />
                <label htmlFor="change_password_chkbx">Change Password</label><br />
            </div>

            { updateState?.message && <p className={updateState.isErrorMessage ? styles.error_flash : styles.success_flash}>{ updateState?.message }</p> }

            <div className={styles.chkbox_w_label}>
                <input type="checkbox" id="tos_chkbox" disabled={!isEditing} required name="tos_chkbox" />
                <label htmlFor="tos_chkbox">I hereby confirm that all the information provided in this form is complete, accurate, and truthful to the best of my knowledge.</label>
            </div>
            <button 
                type="button" 
                disabled={!isEditing || pending} 
                className={styles.update_btn + (!isEditing || pending ? ' ' + styles.btn_disabled : '')}
                onClick={() => setIsUpdating(true)} 
            >
                Update
            </button>
            <button 
                type="button" 
                disabled={!isEditing} 
                onClick={handleDelete} 
                className={styles.update_btn + ' ' + (!isEditing ? styles.btn_disabled : styles.delete_btn )}
            >
                Delete
            </button>
        </div>

        <div className={styles.update_form_divs}>
            <div className={styles.update_form_left}>
                <label htmlFor="firstname">First Name</label><br />
                { updateState?.errors?.firstname && <p className={styles.error_msg}>{ updateState.errors.firstname }</p> }
                <input className={styles.update_input} type="text" disabled={!isEditing} id="firstname" name="firstname" defaultValue={profileData.firstname}  />

                <label htmlFor="lastname">Last Name</label><br />
                { updateState?.errors?.lastname && <p className={styles.error_msg}>{ updateState.errors.lastname }</p> }
                <input className={styles.update_input} type="text" disabled={!isEditing} id="lastname" name="lastname" defaultValue={profileData.lastname} />

                <p>Sex</p>
                { updateState?.errors?.sex && <p className={styles.error_msg}>{ updateState.errors.sex }</p> }
                <div className={styles.radio_group}>
                    <label htmlFor="male">Male</label>
                    <input className={styles.update_input_radio} disabled={!isEditing} type="radio" id="male" name="sex" onChange={handleSelectedSexChange} checked={selectedSex === 'male'} defaultValue={"male"} />
                    <label htmlFor="female">Female</label>
                    <input className={styles.update_input_radio} disabled={!isEditing} type="radio" id="female" name="sex" onChange={handleSelectedSexChange} checked={selectedSex === 'female'} defaultValue={"female"} />
                </div>

                <label htmlFor="birthdate">Birthdate</label><br />
                { updateState?.errors?.birthdate && <p className={styles.error_msg}>{ updateState.errors.birthdate }</p> }
                <input className={styles.update_input} disabled={!isEditing} type="date" id="birthdate" name="birthdate" defaultValue={birthDate} />

                <label htmlFor="address">Address</label><br />
                { updateState?.errors?.address && <p className={styles.error_msg}>{ updateState.errors.address }</p> }
                <input className={styles.update_input} disabled={!isEditing} type="text" id="address" name="address" defaultValue={profileData.address} />

                <label htmlFor="phone_number">Phone Number</label><br />
                { updateState?.errors?.phone_number && <p className={styles.error_msg}>{ updateState.errors.phone_number }</p> }
                <input className={styles.update_input} disabled={!isEditing} type="text" id="phone_number" name="phone_number" defaultValue={profileData.phone_number} />

                <label htmlFor="username">Username</label><br />
                { updateState?.errors?.username && <p className={styles.error_msg}>{ updateState.errors.username }</p> }
                <input className={styles.update_input} disabled={!isEditing} type="text" id="username" name="username" defaultValue={profileData.username} />

                <label htmlFor="email">Email</label><br />
                { updateState?.errors?.email && <p className={styles.error_msg}>{ updateState.errors.email }</p> }
                <input className={styles.update_input} disabled={!isEditing} type="text" id="email" name="email" defaultValue={profileData.email} />

                { !isAdmin &&
                    <>
                        <label htmlFor="current_password">Current Password</label><br />
                        { updateState?.errors?.current_password && <p className={styles.error_msg}>{ updateState.errors.current_password }</p> }
                        { profileData?.oauth_reset_password_done === false && <p className={styles.info_msg}>{ 'Must change password! No need to type anything in this input box' }</p> }
                        <input className={styles.update_input} disabled={!isEditing} type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} id="current_password" name="current_password" />
                    </>
                }

                { isChangePassword && 
                    <>
                        <label htmlFor="password">New Password</label><br />
                        { updateState?.errors?.password && <p className={styles.error_msg}>{ updateState.errors.password }</p> }
                        <input className={styles.update_input} disabled={!isEditing} type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} id="password" name="password" />

                        <label htmlFor="confirm_password">Confirm Password</label><br />
                        { updateState?.errors?.confirm_password && <p className={styles.error_msg}>{ updateState.errors.confirm_password }</p> }
                        <input className={styles.update_input} disabled={!isEditing} type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} id="confirm_password" name="confirm_password" />
                    </>
                }
            </div>

            <div className={styles.update_form_right}>
                <label htmlFor="pwd_id_number">PWD ID Number</label><br />
                { updateState?.errors?.pwd_id_number && 
                    <p className={styles.error_msg}>{ updateState.errors.pwd_id_number}</p> }
                <input 
                    className={styles.update_input} 
                    disabled={!isEditing} 
                    type="text" 
                    id="pwd_id_number" 
                    name="pwd_id_number" 
                    minLength={1}
                    maxLength={50}
                    defaultValue={profileData.pwd_id_number} />

                <label htmlFor="senior_id_number">Senior ID Number</label><br />
                { updateState?.errors?.senior_id_number && 
                    <p className={styles.error_msg}>{ updateState.errors.senior_id_number}</p> }
                <input 
                    className={styles.update_input} 
                    disabled={!isEditing} 
                    type="text" 
                    id="senior_id_number" 
                    name="senior_id_number" 
                    defaultValue={profileData.senior_id_number} />

                <label htmlFor="sss">SSS</label><br />
                { updateState?.errors?.sss && 
                    <p className={styles.error_msg}>{ updateState.errors.sss}</p> }
                <input 
                    className={styles.update_input} 
                    disabled={!isEditing} 
                    type="text" 
                    id="sss" 
                    name="sss" 
                    defaultValue={profileData.sss} />

                <label htmlFor="tin">TIN</label><br />
                { updateState?.errors?.tin && 
                    <p className={styles.error_msg}>{ updateState.errors.tin}</p> }
                <input 
                    className={styles.update_input} 
                    disabled={!isEditing} 
                    type="text" 
                    id="tin" 
                    name="tin" 
                    defaultValue={profileData.tin} />

                <label htmlFor="philhealth">Philhealth</label><br />
                { updateState?.errors?.philhealth && 
                    <p className={styles.error_msg}>{ updateState.errors.philhealth}</p> }
                <input 
                    className={styles.update_input} 
                    disabled={!isEditing} 
                    type="text" 
                    id="philhealth" 
                    name="philhealth" 
                    defaultValue={profileData.philhealth} />

                <WorkExp initial_work_exp={profileData?.work_exp} disabled={!isEditing} work_exp_errors={updateState?.errors?.work_exp} resetSignal={workExpResetSignal} />

                <label htmlFor="disabilities">Disabilities</label><br />
                { updateState?.errors?.disabilities && <p className={styles.error_msg}>{ updateState.errors.disabilities }</p> }
                <Select
                    isMulti
                    options={disabilityOptions}
                    defaultValue={profileData.disabilities}
                    placeholder="Select disabilities"
                    closeMenuOnSelect={false}
                    className={styles.multiselect_input}
                    inputId="disabilities"
                    name="disabilities"
                    styles={multiSelectStyles}
                    isDisabled={!isEditing}
                />

                <label htmlFor="education">Educational Attainment</label><br />
                <p><i>(If you have no educational attainment please select N/A)</i></p>
                { updateState?.errors?.education && <p className={styles.error_msg}>{ updateState.errors.education }</p> }
                <select className={styles.update_input} disabled={!isEditing} id="education" name="education" defaultValue={profileData.education}>
                    <option value="na">N/A</option>
                    <option value="elem">Elementary School</option>
                    <option value="hs">High School</option>
                    <option value="shs">Senior High School</option>
                    <option value="college">College</option>
                </select>
            </div>
        </div>
    </form>
  )
}
