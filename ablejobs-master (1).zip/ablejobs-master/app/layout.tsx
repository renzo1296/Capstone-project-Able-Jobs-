import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import AccessibilitySettings from "./components/AcessibilitySettings";

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: "AbleJobs",
  description: "Emphasizing that ability matters more than disability",
  openGraph: {
    title: "AbleJobs",
    description: "Emphasizing that ability matters more than disability",
    url: 'https://ablejobs.xyz',
    siteName: 'AbleJobs',
    images: [
      {
        url: 'https://ablejobs.xyz/mainLogo.png',
        width: 500,
        height: 500,
        alt: 'AbleJobs Logo',
      },
    ],
    type: 'website',
  }
};

export default function RootLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    return (
        <html lang="en">
            <body className={`${inter.className}`}>
                <Navbar />
                <AccessibilitySettings />
                    {children}
                <Footer />
            </body>
        </html>
    );
}
