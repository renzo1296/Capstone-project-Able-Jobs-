'use client'

import { useSearchParams } from 'next/navigation'
import styles from './oauthbtn.module.css'
import Image from 'next/image'

export default function OAuthBtn() {
  const searchParams = useSearchParams();
  const jobId = searchParams.get('applying_to') || '';

  const redirect_uri = process.env.NEXT_PUBLIC_GOOGLE_REDIRECT_URI!;
  const client_id = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID!;
  const scope = "openid email profile";
  const googleAuthUrl =
    `https://accounts.google.com/o/oauth2/v2/auth?response_type=code&` +
    `client_id=${client_id}&redirect_uri=${redirect_uri}&scope=${encodeURIComponent(scope)}&` +
    `state=${jobId}`;

  return (
    <button
      type="button"
      className={styles.button}
      onClick={() => { window.location.href = googleAuthUrl; }}
    >
      <Image
        src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
        alt="Google logo"
        width={20}
        height={20}
        className={styles.logo}
      />
      Continue with Google
    </button>
  );
}

