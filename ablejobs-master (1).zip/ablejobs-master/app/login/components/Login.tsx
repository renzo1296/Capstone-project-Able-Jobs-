'use client'

import { useActionState } from "react"
import { login, LoginState } from "../action/login"
import { useSearchParams } from 'next/navigation'
import styles from "./login.module.css"

export default function Loginform() {
    const searchParams = useSearchParams();
    const jobId = searchParams.get('applying_to') || '';

    const [loginState, loginAction, pending] = useActionState(
        (prevLoginState: LoginState, formData: FormData) => 
        login(prevLoginState, formData, jobId), undefined);

    return (
        <form className={styles.login_form} action={loginAction}>
            {loginState?.message && (
                <div className={styles.error_message}>
                    {loginState.message}
                </div>
            )}
            
            <div className={styles.form_group}>
                <label htmlFor="username">Username</label>
                <input 
                    className={styles.login_input} 
                    type="text" 
                    id="username" 
                    name="username"
                    placeholder="Enter your username"
                    required
                />
            </div>

            <div className={styles.form_group}>
                <label htmlFor="password">Password</label>
                <input 
                    className={styles.login_input} 
                    type="password" 
                    id="password" 
                    name="password"
                    placeholder="Enter your password" 
                    required
                />
            </div>

            <button 
                className={styles.login_btn} 
                disabled={pending} 
                type="submit"
            >
                {pending ? 'Logging in...' : 'Login'}
            </button>
        </form>
    )
}

