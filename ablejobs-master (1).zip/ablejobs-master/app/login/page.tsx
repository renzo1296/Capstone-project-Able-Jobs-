import { Suspense } from "react"
import NavLink from "../components/NavLink"
import Loginform from "./components/Login"
import styles from "./page.module.css"
import OAuthBtn from "./components/OAuthBtn"

export default function LoginPage() {
  return (
    <main className={styles.login_main_section}>
        <h1>Login</h1>
        <h4>Don&apos;t have an account? <NavLink href="/sign-up"><span className={styles.sign_up_link}>Sign up free!</span></NavLink></h4>
        <br />
        <Suspense>
            <OAuthBtn />
            <Loginform />
        </Suspense>
    </main>
  )
}
