'use server'

import pool from "@/app/lib/db"
import { UserTypeEnum } from "@/app/types/common"
import { createSession } from "@/app/utils/server/auth"
import { redirect } from "next/navigation"

export type LoginState = 
{
    errors?: {
        username?: string[]
        email?: string[]
        password?: string[]
    }
    message?: string
} | undefined

export async function login(prevLoginState: LoginState, formData: FormData, jobId: string): Promise<LoginState> {
    console.log(formData.get("username"), formData.get("password"))

    const entries = {
        'username': formData.get('username') as string,
        'email': formData.get('email'),
        'password': formData.get('password')
    }
    console.log("da entries ", entries);
    console.log(entries.username, entries.password);

    const query = "SELECT * FROM user_ WHERE username=$1 AND password=$2";
    const values = [entries.username, entries.password];
    const res = await pool.query(query, values);

    if (res.rowCount != 1) {
        return { message: "Incorrect username and\/or password" };
    }

    const userType = res.rows[0].user_type;
    await createSession(res.rows[0].id, entries.username, userType);

    if (jobId)
        redirect(`/job/${jobId}`);
    else  {
        if (userType === UserTypeEnum.Values.job_seeker)
            redirect("/profile");
        else
            redirect("/admin/dashboard");
    }
}
