export function getDateOnlyString(dateInp: (string | Date)) {
    if (!dateInp) 
        return "";
    const rawDate = new Date(dateInp);
    const adjustedDate = new Date(rawDate.getTime() - rawDate.getTimezoneOffset() * 60000);
    return adjustedDate.toISOString().split('T')[0];
}
