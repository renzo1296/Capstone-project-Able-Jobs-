export function getCookie(key: string): string | undefined {
    const cookies = document.cookie.split('; ');
    const found = cookies.find(row => row.startsWith(`${key}=`));
    return found ? decodeURIComponent(found.split('=')[1]) : undefined;
}
