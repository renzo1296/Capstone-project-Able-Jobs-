/** 
 * Converts user input to a normalized "key" string: lowercase, underscores, trimmed, single spaces.
 * Example: "  Mentally  Retarded " -> "mentally_retarded"
 */
export function normalizeKey(input: string): string {
    return input
        .trim()                // remove leading/trailing spaces
        .replace(/\s+/g, ' ')  // collapse multiple spaces into 1
        .toLowerCase()         // lowercase
        .replace(/ /g, '_');   // replace spaces with underscore
}

/**
 * Converts a "key" string to a human-friendly "name".
 * Example: "mentally_retarded" -> "Mentally Retarded"
 */
export function keyToName(key: string): string {
    return key 
        .split('_')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
}

/**
 * Given a user input (like the name), returns both key and formatted name.
 * Example: "  Mentally Retarded " -> { key: "mentally_retarded", name: "Mentally Retarded" }
 */
export function generateKeyAndName(input: string): { key: string; name: string } {
    const key = normalizeKey(input);
    const name = keyToName(key);
    return { key, name };
}

