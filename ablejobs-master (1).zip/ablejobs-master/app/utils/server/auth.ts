'use server'

import { jwtVerify, SignJWT } from "jose"
import { cookies } from "next/headers"
import { redirect } from "next/navigation";

const secretKey = process.env.SECRET_KEY;
const encodedKey = new TextEncoder().encode(secretKey);

type SessionPayload = {
    id: number,
    username: string,
    user_type: string,
    expiresAt: Date
} | undefined;

export async function createSession(id: number, username: string, user_type: string) {
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    const data: SessionPayload = { id, username, user_type, expiresAt }; 
    const jwtToken = await new SignJWT(data)
        .setProtectedHeader({ alg: "HS256"})
        .setIssuedAt()
        .setExpirationTime("7d")
        .sign(encodedKey);

    (await cookies()).set("session", jwtToken, {
        httpOnly: true,
        secure: true,
        expires: expiresAt
    });
}

export async function deleteSession() {
    (await cookies()).delete("session");
}

export async function decryptSession(jwtToken: string | undefined): Promise<SessionPayload | undefined> {
    try {
        const { payload } = await jwtVerify<SessionPayload>(jwtToken!, encodedKey, {
            algorithms: ["HS256"]
        });
        return payload;
    }
    catch (error: unknown) {
        if (error instanceof Error) {
            console.error('Caught error:', error.message);
        } else {
            console.error('Unknown error:', error);
        }
        console.error('Context:', "Failed to verify session!");
    }
}

export async function getSession(): Promise<SessionPayload> {
    const cookieStore = await cookies();
    const session = cookieStore.get('session')?.value;
    const sessionPayload = await decryptSession(session);
    return sessionPayload;
}

export async function logout() {
    await deleteSession();
    redirect("/")
}


