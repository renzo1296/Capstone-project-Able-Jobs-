import fs from 'fs/promises';
import { join } from 'path';

export const isFileSelected = (file: File | undefined): boolean => 
    file !== undefined && 
    (file.name !== undefined && file.size !== undefined &&
    (file.name !== 'undefined' || file.size > 0));

export const renameDirectory = async (directory: string, oldName: string, newName: string): Promise<boolean> => {
  try {
    const oldPath = join(directory, oldName);
    const newPath = join(directory, newName);
    await fs.rename(oldPath, newPath);
    return true;
  } catch (error) {
    console.error('Error renaming folder:', error);
    return false;
  }
}

export const deleteDirectory = async (directory: string, folderName: string): Promise<boolean> => {
    try {
        const folderPath = join(directory, folderName);
        await fs.rm(folderPath, { recursive: true, force: true });
        return true;
    } catch (error) {
        console.error('Error deleting directory:', error);
        return false;
    }
}

export const deleteFile = async (directory: string, filename: string): Promise<boolean> => {
    try {
        const filePath = join(directory, filename);
        await fs.unlink(filePath);
        return true
    } catch (error) {
        console.error('Error deleting file:', error);
        return false;
    }
}

export const filenameExists = async (directory: string, filename: string): Promise<boolean> => {
    try {
        const files = await fs.readdir(directory);
        console.log("files: ", files);
        return files.some(file => file.startsWith(filename));
    } catch (error) {
        console.error('Error reading directory:', error);
        return false;
    }
}

export const getFileWithFilename = async (directory: string, filename: string): Promise<string | undefined> => {
    try {
        const files = await fs.readdir(directory);
        return files.find(file => file.startsWith(filename));
    } catch (error) {
        console.error('Error reading directory:', error);
        return "";
    }
}

export const createDirIfNotExist = async (path: string): Promise<void> => {
    try {
        if (!await pathExists(path)) {
            await fs.mkdir(path, { recursive: true });
        }
    }
    catch (error) {
        console.error('Error creating directory:', error);
    }
}

export const pathExists = async (path: string): Promise<boolean> => {
    try { 
        await fs.access(path); 
        return true;
    }
    catch { return false; }
}

export const writeFileObjToFile = async (file: File, filePath: string): Promise<void> => {
    const byteArr = await file.arrayBuffer();
    const typedArr = new Uint8Array(byteArr);
    await fs.writeFile(filePath, typedArr);
}
