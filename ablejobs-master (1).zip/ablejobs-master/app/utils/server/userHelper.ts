'use server'

import pool from "@/app/lib/db";
import { SignUpFormSchema } from "@/app/sign-up/definitions";
import { UserTypeEnum } from "@/app/types/common";
import { PoolClient } from "pg";
import { createSession } from "./auth";
import { isFileSelected } from "./helpers";
import { BUCKET_NAME, CreateBucket, getUserDir, ListBucketFiles, RemoveFiles, UploadFile } from "@/app/lib/supabase";
import path from "path";
import { UpdateFormSchema } from "@/app/profile/definitions";

export async function createJobSeeker(client: PoolClient, jobSeeker: SignUpFormSchema, isOAuth: boolean = false) {
    await client.query('BEGIN');

    // Insert user
    const addUserQuery = `INSERT INTO user_(user_type, username, email, password${isOAuth ? ', oauth_reset_password_done' : ''})
                          VALUES($1, $2, $3, $4${isOAuth ? ', $5' : ''})
                          RETURNING *`;
    const addUserValues = [
        UserTypeEnum.Values.job_seeker,
        jobSeeker.username, 
        jobSeeker.email, 
        jobSeeker.password,
        ...(isOAuth ? [!isOAuth] : [])
    ];
    const user = (await client.query(addUserQuery, addUserValues)).rows[0];

    // Insert job_seeker
    const addJobSeekerQuery = `INSERT INTO job_seeker_(
        user_id, firstname, lastname, sex, birthdate, address, phone_number,
        pwd_id_number, senior_id_number, sss, tin, philhealth, education
    ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`;
    const addJobSeekerValues = [
        user.id,
        jobSeeker.firstname, 
        jobSeeker.lastname, 
        jobSeeker.sex, 
        jobSeeker.birthdate, 
        jobSeeker.address, 
        jobSeeker.phone_number, 
        jobSeeker.pwd_id_number, 
        jobSeeker.senior_id_number, 
        jobSeeker.sss,
        jobSeeker.tin,
        jobSeeker.philhealth,
        jobSeeker.education
    ];
    await client.query(addJobSeekerQuery, addJobSeekerValues);

    // insert work experience
    if (jobSeeker.work_exp?.length) {
        const addWorkExpQuery = `INSERT INTO work_exp_(
            user_id, company, position, from_date, to_date, is_present
        ) VALUES ${jobSeeker.work_exp.map((_, i) => 
            `($1, $${i*5+2}, $${i*5+3}, $${i*5+4}, $${i*5+5}, $${i*5+6})`
        ).join(', ')}`;

        const addWorkExpValues = jobSeeker.work_exp.flatMap(item => [
            item.company,
            item.position,
            item.from,
            item.to || null,
            item.is_present || false
        ]);
        await client.query(addWorkExpQuery, [user.id, ...addWorkExpValues]);
    }

    // insert disabilities
    if (jobSeeker.disabilities?.length) {
        const insertQuery = `
            INSERT INTO job_seeker_disability_type_ (user_id, disability_type)
            VALUES ${jobSeeker.disabilities
                .map((_, i) => `($1, $${i + 2})`)
                .join(", ")}
        `;

        await client.query(insertQuery, [
            user.id,
            ...jobSeeker.disabilities
        ]);
    }

    await client.query('COMMIT');
}

export async function handleFileSubmissions(jobSeeker: SignUpFormSchema | UpdateFormSchema) {
    // create bucket if doesn't exist
    await CreateBucket(BUCKET_NAME);

    // handle files
    const userDir = getUserDir(jobSeeker.username);
    const currentUserFiles = await ListBucketFiles(userDir);

    await upsertFile(jobSeeker.profile_pic as File, 'profile_pic');
    await upsertFile(jobSeeker.pwd_id_pic as File, 'pwd_id_pic');
    await upsertFile(jobSeeker.resume_file as File, 'resume_file');
    await upsertFile(jobSeeker.government_issued_id_pic as File, 'government_issued_id_pic');
    await upsertFile(jobSeeker.nbi_clearance as File, 'nbi_clearance');
    await upsertFile(jobSeeker.tor as File, 'tor');

    async function upsertFile(file: File, fileName: string) {
        if (!isFileSelected(file)) 
            return;

        const existingFilenames = currentUserFiles.filter(file => file.name.startsWith(fileName));
        await RemoveFiles(existingFilenames.map(file => `${userDir}/${file.name}`));
        const fileExt = path.extname(file.name);
        await UploadFile(`${userDir}/${fileName}_${crypto.randomUUID()}${fileExt}`, file);
    }
}

export async function userExistsByEmail(email: string) {
    const query = "SELECT * FROM user_ WHERE email=$1";
    const values = [email];
    const res = await pool.query(query, values);
    return res.rowCount != 0;
}

export async function loginUserByEmail(email: string) {
    const query = "SELECT * FROM user_ WHERE email=$1";
    const values = [email];
    const res = (await pool.query(query, values)).rows[0];
    if (res.rowCount != 0) {
        await createSession(res.id, res.username, res.user_type);
    }
}

export async function generatePassword(length: number = 12) {
  const chars =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+";
  return Array.from({ length }, () =>
    chars.charAt(Math.floor(Math.random() * chars.length))
  ).join("");
}
