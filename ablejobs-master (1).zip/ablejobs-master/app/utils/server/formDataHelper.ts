import { WorkExpItem } from "@/app/sign-up/action/signup";

export function parseWorkExp(formData: FormData): WorkExpItem[] {
    const exp: WorkExpItem[] = [];

    for (const [key, value] of formData.entries()) {
        const match = key.match(/^work_exp\[(\d+)]\[(\w+)]$/);
        if (!match) continue;

        const index = parseInt(match[1], 10);
        const field = match[2] as keyof WorkExpItem;

        // initialize empty object if not exists
        if (!exp[index]) exp[index] = { company: '', position: '', from: '' };

        // assign value
        if (field === "is_present") {
            exp[index][field] = value === "on"; // convert checkbox
        } else if (!(value instanceof File)){
            exp[index][field] = value;
        }
    }

    return exp;
}
