import Image from "next/image";
import styles from "./JobCard.module.css";
import { } from '@fortawesome/free-brands-svg-icons'
import { faPesoSign, faLocationDot } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useRouter } from "next/navigation"
import { Job } from "@/app/job/[id]/definitions";

type JobCardProps = {
    job: Job
}

export default function JobCard({ job }: JobCardProps) {
    const companyPicStyle = {
        width: '50px',
        height: 'auto'
    }

    const router = useRouter();

    const handleRedirect = () => {
        console.log("redirecting??");
        router.push(`/job/${job.id}`);
    };

    return (
        <div className={styles.job_card}>
            <div className={styles.job_card_details}>
                <div className={styles.job_card_header}>
                    <Image
                        src="/companyDefaultLogo.png"
                        alt="Company Logo"
                        width={0}
                        height={0}
                        sizes="100vw"
                        style={companyPicStyle}
                    />
                    <div className={styles.job_card_header_employer_name}>
                        { job.company_name === undefined ? 
                            "MAHALAXMI PHARMACEUTICALS DISTRIBUTORS"
                            : job.company_name }
                    </div>
                </div>
                <p className={styles.job_card_title}>
                    { job.job_title === undefined ? 
                        "Computer Operator"
                        : job.job_title }
                </p>
                <div className={styles.job_card_job_type}>
                    { job.job_type === undefined ? 
                        "Full Time"
                        : job.job_type }
                </div>
                <div className={styles.job_card_salary_area}>
                    <FontAwesomeIcon icon={faPesoSign} height={25} color={"#66b85d"} />
                    <span className={styles.salary_label}>Salary: </span>
                    <span className={styles.salary_amount}>
                    { job.monthly_salary === undefined ? 
                        "15000"
                        : job.monthly_salary }
                    </span>
                </div>
                <div className={styles.job_card_location_lbl_area}>
                    <FontAwesomeIcon icon={faLocationDot} height={25} color={"#66b85d"} />
                    <span className={styles.salary_label}>City: </span>
                </div>
                <div className={styles.job_card_location_area}>
                    <span className={styles.job_location}>
                        Quezon City
                    </span>
                </div>
            </div>
            <hr className={styles.job_card_separator} />
            <div className={styles.job_card_apply_area}>
                <button disabled={job.deleted} onClick={handleRedirect} className={styles.job_apply_btn + ' ' + (job.deleted ? styles.job_closed_btn : '')}>{job.deleted ? "Closed" : "Apply"}</button>
            </div>
        </div>
    )
}
