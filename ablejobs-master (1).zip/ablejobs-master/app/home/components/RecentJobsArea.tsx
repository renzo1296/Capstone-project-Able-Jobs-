'use client'

import { useState, useEffect } from 'react'
import JobTypeBtn from './JobTypeBtn'
import styles from './RecentJobsArea.module.css'
import JobCard from './JobCard';
import { Job } from '@/app/job/[id]/definitions';

export default function RecentJobsArea() { 
    const [jobTypeBtnState, setJobTypeBtnState] = useState('full_time');
    const [jobsState, setJobsState] = useState<Job[]>([]);

    useEffect(() => {
        const fetchJobs = async () => {
            const res = await fetch(`/api/jobs?job_type=full_time`);
            const data = await res.json();
            setJobsState(data);
        };
        fetchJobs();
    }, []);

    useEffect(() => {
        const fetchJobs = async () => {
            const res = await fetch(`/api/jobs?job_type=${jobTypeBtnState}`);
            const data = await res.json();
            setJobsState(data);
        };
        fetchJobs();
    }, [jobTypeBtnState]);
    
    return (
        <div className={styles.sec3}>
            <h1>Recent Jobs</h1>
            <div className={styles.sec3_job_type_btns}>
                <JobTypeBtn selected={jobTypeBtnState === 'full_time'} job_type_key={'full_time'} job_type_value={'Full Time'} setJobTypeBtnState={setJobTypeBtnState} />
                <JobTypeBtn selected={jobTypeBtnState === 'part_time'} job_type_key={'part_time'} job_type_value={'Part Time'} setJobTypeBtnState={setJobTypeBtnState} />
                <JobTypeBtn selected={jobTypeBtnState === 'ojt'} job_type_key={'ojt'} job_type_value={'OJT'} setJobTypeBtnState={setJobTypeBtnState} />
            </div>
            <div className={styles.sec3_recent_jobs_area}>
                { jobsState.map( job => (
                    <JobCard key={job.id} job={job}  />
                ))}
            </div>
        </div>
    )

}
