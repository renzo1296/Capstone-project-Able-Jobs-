import { Dispatch, SetStateAction } from "react";
import styles from "./JobTypeBtn.module.css";

type Props = {
    children?: string
    selected?: boolean
    setJobTypeBtnState: Dispatch<SetStateAction<string>>
    job_type_key: string
    job_type_value: string
}

export default function JobTypeBtn({ job_type_key, job_type_value, selected, setJobTypeBtnState }: Props) {
  return (
    <div onClick={() => setJobTypeBtnState(job_type_key)} className={styles.job_type_btn}>
        <span className={styles.job_type_btn_bg + (selected ? ' ' + styles.active : '')}>
        </span>
        <span className={styles.job_type_btn_lbl}>
            { job_type_value }
        </span>
    </div>
  )
}
