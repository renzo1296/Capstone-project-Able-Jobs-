'use client'

import Select from "react-select"
import styles from "./HomeJobSearch.module.css"
import { educationOptions, MultiSelectOption } from "@/app/types/common"
import { useRouter } from "next/navigation"
import { useTheme } from '@/app/context/ThemeContext'
import { getMultiSelectStyles } from '@/app/types/styles'

interface HomeJobSearchProps {
    cityOptions: MultiSelectOption[]
    disabilityOptions: MultiSelectOption[]
}

export default function HomeJobSearch({ cityOptions, disabilityOptions }: HomeJobSearchProps) {
    const { theme } = useTheme()
    const isDarkMode = theme === 'dark'
    const multiSelectStyles = getMultiSelectStyles(isDarkMode);
    const router = useRouter()

    const handleRedirect = () => {
        router.push('/job-search')
    }

    return (
        <div className={styles.home_job_search_container}>
            <div className={styles.search_filters}>
                <Select
                    isMulti
                    options={disabilityOptions}
                    placeholder="Disability Type"
                    closeMenuOnSelect={false}
                    className={styles.multiselect_input}
                    styles={multiSelectStyles}
                />
                <Select
                    isMulti
                    options={cityOptions}
                    placeholder="Location"
                    closeMenuOnSelect={false}
                    className={styles.multiselect_input}
                    styles={multiSelectStyles}
                />
                <Select
                    isMulti
                    options={educationOptions}
                    placeholder="Qualification"
                    closeMenuOnSelect={false}
                    className={styles.multiselect_input}
                    styles={multiSelectStyles}
                />
            </div>
            <button onClick={handleRedirect} className={styles.find_job_btn} type="submit">Find Jobs</button>
        </div>
    )
}
