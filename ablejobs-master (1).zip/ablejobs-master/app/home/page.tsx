import styles from "./page.module.css";
import Image from "next/image"
import HomeJobSearch from "./components/HomeJobSearch";
import RecentJobsArea from "./components/RecentJobsArea";
import { getCityOptions, getDisabilityOptions } from "../lib/db";

export default async function Home() {
    const mainLogoStyle = {
        width: '100%',
        "maxWidth": '300px',
        "minWidth": '10vh',
        height: 'auto'
    }
    const iconsStyle = {
        width: '100%',
        "maxWidth": '150px',
        height: 'auto',
        "borderRadius": '50%'
    }
    const sponsorLogosStyle = {
        width: '100%',
        "maxWidth": '200px',
        height: 'auto',
    }

    const cityOptions = await getCityOptions();
    const disabilityOptions = await getDisabilityOptions();

    return (
        <div>
            <div className={styles.sec1}>
                <div className={styles.sec1_logos}>
                    <div className={styles.sec1_logos_left}>
                        <div className={styles.sec1_logos_left_icons}>
                            <Image 
                                src="/speechDisorderLogo.png"
                                alt="brain logo"
                                width={0}
                                height={0}
                                sizes="100vw"
                                style={iconsStyle}
                            />
                            <Image 
                                src="/brainLogo.png"
                                alt="brain logo"
                                width={0}
                                height={0}
                                sizes="100vw"
                                style={iconsStyle}
                            />
                        </div>
                        <div className={styles.sec1_logos_left_slogan}>
                            Ability Over Disability
                        </div>
                    </div>
                    <div className={styles.sec1_main_logo}>
                        <Image 
                            src="/mainlogo.png"
                            alt="main logo"
                            width={0}
                            height={0}
                            sizes="100vw"
                            style={mainLogoStyle}
                        />
                    </div>
                    <div className={styles.sec1_logos_right}>
                        <div className={styles.sec1_logos_right_icons}>
                            <Image 
                                src="/networkLogo.png"
                                alt="brain logo"
                                width={0}
                                height={0}
                                sizes="100vw"
                                style={iconsStyle}
                            />
                            <Image 
                                src="/deafLogo.png"
                                alt="brain logo"
                                width={0}
                                height={0}
                                sizes="100vw"
                                style={iconsStyle}
                            />
                        </div>
                        <div className={styles.sec1_logos_right_slogan}>
                            Empowering Every Ability
                        </div>
                    </div>
                </div>
                <div className={styles.search_container}>
                    <p className={styles.search_slogan}> Find inclusive jobs and livelihood opportunities with leading employers right here!</p>
                    <HomeJobSearch cityOptions={cityOptions} disabilityOptions={disabilityOptions} />
                </div>
            </div>
            
            <div className={styles.sec2}>
                <Image 
                    src="/smSupermallsLogo.jpg"
                    alt="brain logo"
                    width={0}
                    height={0}
                    sizes="100vw"
                    style={sponsorLogosStyle}
                />
                <Image 
                    src="/uniqloLogo.png"
                    alt="brain logo"
                    width={0}
                    height={0}
                    sizes="100vw"
                    style={sponsorLogosStyle}
                />
            </div>

            <RecentJobsArea />
        </div>
    );
}
