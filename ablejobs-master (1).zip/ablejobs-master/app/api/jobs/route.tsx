import { searchJobsInDBWithFilters } from "@/app/job-search/actions/job";
import { JobSearchFormSchema } from "@/app/job-search/definitions";
import { JobTypeEnum } from "@/app/types/common";
import { NextRequest, NextResponse } from "next/server";
import { deleteJobById } from "@/app/job/[id]/actions/jobDelete";
import pool from "@/app/lib/db"
import { SendEmail } from "@/app/lib/brevo";
import CloseJobNotifEmail, { CloseJobNotifEmailProps } from "@/app/job/[id]/components/CloseJobNotifEmail";
import { Job } from "@/app/job/[id]/definitions";

export async function GET(req: NextRequest) {
    const searchParams = req.nextUrl.searchParams;
    const job_type = searchParams.get('job_type');

    const parsed_job_type = JobTypeEnum.safeParse(job_type);
    if (!parsed_job_type.success) {
        return NextResponse.json({ error: "Missing job_type" }, { status: 400 });
    }

    const jobSearchFilters : JobSearchFormSchema = {
        'company_name': '', 
        'job_title': '',
        'job_type': [ parsed_job_type.data ],
        'city': [],
        'monthly_salary_range_start': 0,
        'monthly_salary_range_end': 0,
        'location': '', 
        'disabilities': [],
        'education': [],
        'sort_by': 'sort_by_date_posted'
    };

    const jobs = await searchJobsInDBWithFilters(jobSearchFilters);

    return Response.json(jobs);
}


export async function DELETE(req: Request) {
    const { job_id } = await req.json();

    if (!job_id) {
        return new Response(JSON.stringify({ error: "Missing job_id" }), { status: 400 });
    }

    // check first if it's closed
    const query1 = `
    SELECT *
    FROM job_
    WHERE id = $1
    `;
    const res1 = await pool.query<Job>(query1, [job_id]);
    const job1 = res1.rows[0];
    if (job1.deleted) {
         return new Response(JSON.stringify({ error: "Job already closed" }), { status: 404 });
    }

    const deletedJob = await deleteJobById(job_id);

    if (!deletedJob) {
         return new Response(JSON.stringify({ error: "Job not found" }), { status: 404 });
    }

    // job closed succesfully here 
    // so send email to all people who applied to this job
    const query = `
        SELECT u.email, js.firstname, js.lastname, j.job_title, j.company_name
        FROM job_application_ ja
        JOIN user_ u ON ja.user_id = u.id
        JOIN job_seeker_ js ON u.id = js.user_id
        JOIN job_ j ON ja.job_id = j.id
        WHERE ja.job_id = $1
    `;
    const values = [job_id];
    const res = await pool.query<{ email: string; firstname: string; lastname: string; job_title: string; company_name: string }>(query, values);
    const users = res.rows;
    for (const user of users) {
        const props: CloseJobNotifEmailProps = {
            first_name: user.firstname,
            job_title: user.job_title,
            company_name: user.company_name
        }

        const ReactDOMServer = await import("react-dom/server");
        const html = ReactDOMServer.renderToStaticMarkup(
            <CloseJobNotifEmail {...props} />
        );

        // don't await, fire and forget
        SendEmail(
            `Job Closed – ${user.job_title}`,
            html, 
            `${user.firstname} ${user.lastname}`, 
            user.email
        );
    }

    return new Response(JSON.stringify({ success: true, deleted: deletedJob }));
}

