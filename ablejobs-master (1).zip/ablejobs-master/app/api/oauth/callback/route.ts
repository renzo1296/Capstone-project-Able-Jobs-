import { NextRequest } from "next/server";
import pool from "@/app/lib/db";
import { createJobSeeker, generatePassword, loginUserByEmail, userExistsByEmail } from "@/app/utils/server/userHelper";
import { SignUpFormSchema } from "@/app/sign-up/definitions";
import { EducationEnum, SexEnum } from "@/app/types/common";
import { redirect } from "next/navigation";

export async function GET(req: NextRequest) {
    const searchParams = req.nextUrl.searchParams;
    const error = searchParams.get("error");
    const code = searchParams.get("code");

    if (error !== null) {
        console.log("it fuckin errored, user cancelled!!", error);
        redirect("/profile");
    }

    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
            code: code!,
            client_id: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID!,
            client_secret: process.env.GOOGLE_CLIENT_SECRET!,
            redirect_uri: process.env.NEXT_PUBLIC_GOOGLE_REDIRECT_URI!,
            grant_type: "authorization_code",
        }),
    });

    const tokens = await tokenRes.json();
    if (tokens.error !== undefined) {
        console.log("it errored while requesting token omfg");
        redirect("/profile");
    }

    const userRes = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
        headers: { Authorization: `Bearer ${tokens.access_token}` },
    });

    const user = await userRes.json();

    if (!(await userExistsByEmail(user.email))) {
        // signup
        const client = await pool.connect();
        try {
            await createJobSeeker(client, {
                username: user.id,
                email: user.email,
                password: await generatePassword(),
                firstname: user.given_name,
                lastname: user.family_name,
                sex: SexEnum.Values.male,
                birthdate: "1970-01-01",
                address: "",
                phone_number: "",
                pwd_id_number: "",
                senior_id_number: "",
                sss: "",
                tin: "",
                philhealth: "",
                education: EducationEnum.Values.na
            } as SignUpFormSchema, true);
        }
        catch (error: unknown) {
            console.error('Context:', "Database insert error");
            if (error instanceof Error) {
                console.error('Caught error:', error.message);
            } 
            else {
                console.error('Unknown error:', error);
            }
        }
        finally {
            client.release();
        }
    }
    // login
    await loginUserByEmail(user.email);

    redirect("/profile");
}


