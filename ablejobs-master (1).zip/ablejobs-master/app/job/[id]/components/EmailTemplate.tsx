import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faCheckCircle } from '@fortawesome/free-solid-svg-icons'
import { CSSProperties } from "react"
import Link from "next/link"

export type EmailTemplateProps = {
    applicant_username: string
    job_title: string
    company_name: string
    host: string
}

export default function EmailTemplate({ applicant_username, job_title, company_name, host }: EmailTemplateProps) {
    const success_area:CSSProperties = {
        justifyContent: 'center',
        alignItems: 'center',
        padding: '3rem',
        borderRadius: '10px',
        margin: 'auto',
        marginTop: '5rem',
        maxWidth: '1000px',
        color: '#2B796F',
        backgroundColor: '#D5FFC9'
    };
    const hdr1: CSSProperties = {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        gap: '1rem',
        fontSize: '2rem'
    };

    const checkIcon: CSSProperties = {
        width: '3rem',
    };
    const sub1: CSSProperties = {
        marginTop: '.5rem'
    };
    const applicantSub1: CSSProperties = {
        ...sub1,
        fontSize: 'larger',
        fontWeight:' bold'
    };
    const manual_link: CSSProperties = {
        textDecoration: 'underline',
        color: '#2B796F',
    };

    return (
        <div style={success_area}>
            <div style={hdr1}>
                <FontAwesomeIcon style={checkIcon} icon={faCheckCircle} width={25}/>
                Successfully applied!
            </div>
            <p style={applicantSub1}>
                Hi {applicant_username},
            </p>
            <p style={sub1}>
                You&apos;ve successfully applied to the <b>{job_title}</b> position at <b>{company_name}</b> 
            </p>
            <p style={sub1}>
                We&apos;ll notify you as soon as there&apos;s an update from the employer. 
            </p>
            <p style={sub1}>
                In the meantime, you can view your application status in your <Link style={manual_link} target={'_blank'} href={`${host}/job/application`}>Applications Page.</Link>
            </p>
            <br />
            <p style={sub1}>
                Good luck!
            </p>
            <p style={sub1}>
                — <b>AbleJobs Team</b>
            </p>
        </div>
    )
}
