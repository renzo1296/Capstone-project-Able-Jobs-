import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faTimesCircle } from '@fortawesome/free-solid-svg-icons'
import { CSSProperties } from "react"

export type CloseJobNotifEmailProps = {
    first_name: string
    job_title: string
    company_name: string
}

export default function CloseJobNotifEmail({ 
    first_name, 
    job_title, 
    company_name, }: CloseJobNotifEmailProps) {
    const container: CSSProperties = {
        justifyContent: 'center',
        alignItems: 'center',
        padding: '3rem',
        borderRadius: '10px',
        margin: 'auto',
        marginTop: '5rem',
        maxWidth: '1000px',
        color: '#7B1A1A',           // dark red text
        backgroundColor: '#FFD6D6'  // soft red/pink background
    };

    const hdr1: CSSProperties = {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        gap: '1rem',
        fontSize: '2rem'
    };

    const xIcon: CSSProperties = {
        width: '3rem',
        color: '#B71C1C'            // red icon
    };

    const sub1: CSSProperties = {
        marginTop: '.5rem'
    };

    const applicantSub1: CSSProperties = {
        ...sub1,
        fontSize: 'larger',
        fontWeight: 'bold'
    };
    return (
        <div style={container}>
            <div style={hdr1}>
                <FontAwesomeIcon style={xIcon} icon={faTimesCircle} width={25}/>
                Job Closed – {job_title}
            </div>
            <p style={applicantSub1}>
                Hi {first_name},

            </p>
            <p style={sub1}>
                The job &ldquo;{job_title}&rdquo; at {company_name} is now closed and no longer accepting applications.
            </p>
            <p style={sub1}>
                Thank you for your interest!
            </p>
            <br />
            <p style={sub1}>
                — <b>AbleJobs Team</b>
            </p>
        </div>
    )
}

