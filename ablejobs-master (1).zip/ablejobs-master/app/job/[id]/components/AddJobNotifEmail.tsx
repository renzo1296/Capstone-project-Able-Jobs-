import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faBriefcase } from "@fortawesome/free-solid-svg-icons"
import { CSSProperties } from "react"

export type AddJobNotifEmailProps = {
    first_name: string
    company_name: string
    job_title: string
    job_type: string
    job_details: string
    location: string
    monthly_salary: string
    disabilities: string
    city: string
    education: string
}

export default function AddJobNotifEmail({
    first_name,
    company_name,
    job_title,
    job_type,
    job_details,
    location,
    monthly_salary,
    disabilities,
    city,
    education,
}: AddJobNotifEmailProps) {
    const container: CSSProperties = {
        justifyContent: 'center',
        alignItems: 'center',
        padding: '3rem',
        borderRadius: '10px',
        margin: 'auto',
        marginTop: '5rem',
        maxWidth: '1000px',
        color: '#1A4E7B',            // dark blue text
        backgroundColor: '#D6EBFF'   // soft blue background
    }

    const hdr1: CSSProperties = {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        gap: '1rem',
        fontSize: '2rem'
    }

    const briefcaseIcon: CSSProperties = {
        width: '3rem',
        color: '#1565C0'             // blue icon
    }

    const sub1: CSSProperties = {
        marginTop: '.5rem'
    }

    const applicantSub1: CSSProperties = {
        ...sub1,
        fontSize: 'larger',
        fontWeight: 'bold'
    }

    return (
        <div style={container}>
            <div style={hdr1}>
                <FontAwesomeIcon style={briefcaseIcon} icon={faBriefcase} width={25}/>
                New Job Posted – {job_title}
            </div>
            <p style={applicantSub1}>
                Hi {first_name},
            </p>
            <p style={sub1}>
                A new job &ldquo;{job_title}&rdquo; at {company_name} has just been posted!
            </p>
            <p style={sub1}><b>Type:</b> {job_type}</p>
            <p style={sub1}><b>Location:</b> {location}, {city}</p>
            <p style={sub1}><b>Monthly Salary:</b> {monthly_salary}</p>
            <p style={sub1}><b>Education Required:</b> {education}</p>
            <p style={sub1}><b>Disabilities Accepted:</b> {disabilities}</p>
            <p style={sub1}><b>Details:</b> {job_details}</p>
            <br />
            <p style={sub1}>
                — <b>AbleJobs Team</b>
            </p>
        </div>
    )
}

