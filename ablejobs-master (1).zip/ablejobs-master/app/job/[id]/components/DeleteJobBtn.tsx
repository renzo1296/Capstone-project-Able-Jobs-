'use client'

import ConfirmationModal from "@/app/components/ConfirmationModal";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { createPortal } from "react-dom";
import styles from "./DeleteJobBtn.module.css";

export default function DeleteJobBtn({ jobId, isClosed }: { jobId: string; isClosed: boolean }) {
    const router = useRouter();
    const [isDeleting, setIsDeleting] = useState(false);

    async function handleDelete() {
        const res = await fetch(`/api/jobs`, {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ job_id: jobId }),
        });

        if (res.ok) {
            router.push("/"); // redirect after delete
        } else {
            const err = await res.json();
            alert("Delete failed: " + err.error);
        }
    }

    return (
        <>
            {isDeleting &&
                createPortal(
                    <ConfirmationModal
                        onNo={() => setIsDeleting(false)}
                        onYes={handleDelete}
                    />,
                    globalThis.document.body
                )}
            <button
                disabled={isClosed}
                onClick={() => setIsDeleting(true)}
                className={styles.deleteButton}
            >
                {isClosed ? "Closed" : "Delete"}
            </button>
        </>
    );
}
