import styles from "./JobDetailSection.module.css"
import React from 'react'

export type JobInfo = {
    jobInfoLabel: string,
    jobInfoLabelValue: string
};

type JobDetailSectionProps = {
    sectionHeader: string
    borderColor: string
    jobInfo: JobInfo[]
};

export default async function JobDetailSection(props: JobDetailSectionProps) {
    const style = {
        "borderColor": "red"
    }
    return (
        <>
            <h2 className={styles.job_section_header}>{props.sectionHeader}</h2>
            <div className={styles.job_details_container + ' ' + style} style={{borderLeftColor: props.borderColor }}>
                { props.jobInfo.map((jobInfo, index) => ( 
                     <React.Fragment key={index}>
                        <p className={styles.job_info_lbl}>{jobInfo.jobInfoLabel}</p>
                        <p className={styles.job_info_lbl_val}>{jobInfo.jobInfoLabelValue}</p>
                    </React.Fragment>
                ))}
            </div>
        </>
    )
}
