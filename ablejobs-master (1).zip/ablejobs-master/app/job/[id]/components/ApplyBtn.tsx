'use client'

import styles from "./ApplyBtn.module.css"
import ReactDOMServer from 'react-dom/server';
import EmailTemplate, { EmailTemplateProps } from "./EmailTemplate";
import { useEffect, useActionState, useState } from 'react';
import { jobApply } from "../actions/jobApply";

type ApplyBtnProps = {
    job_id: string
    email_template_props: Omit<EmailTemplateProps, 'host'>
    is_closed: boolean
}

export default function ApplyBtn({ job_id, email_template_props, is_closed }: ApplyBtnProps) {
    const [origin, setOrigin] = useState<string | null>(null);

    useEffect(() => {
        setOrigin(window.location.origin);
    }, []);

    const comp = <EmailTemplate applicant_username={email_template_props.applicant_username} company_name={email_template_props.company_name} job_title={email_template_props.job_title} host={origin ?? ''} />;
    const [jobApplyState, jobApplyAction, pending] = useActionState(jobApply, undefined);

    return (
        <>
            <form action={jobApplyAction} className={styles.apply_btn_area}>
                <input type="hidden" name="jobId" value={job_id} />
                <input type="hidden" name="emailContent" value={ ReactDOMServer.renderToStaticMarkup(comp) } />
                <button 
                    disabled={is_closed || pending} 
                    className={styles.job_apply_btn + ((pending || is_closed) ? ' '+styles.btn_disabled : '')}
                    >
                    {
                        is_closed ? "Closed" :
                        ((email_template_props.applicant_username ? '' : 'Login & ' ) + 'Apply')
                    }
                </button>
            </form>
            {jobApplyState?.message && <p className={styles.error_msg}>{jobApplyState.message}</p>}
        </>
    )
}
