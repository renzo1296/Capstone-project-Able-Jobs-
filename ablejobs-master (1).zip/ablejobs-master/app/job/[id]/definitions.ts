import { EducationEnum, JobTypeEnum } from "@/app/types/common";

export interface Job {
    id: number;
    company_name: string;
    job_title: string;
    job_type: JobTypeEnum;
    job_details: string | null;
    city_id: number;
    location: string;
    monthly_salary: number;
    education: EducationEnum;
    date_posted: Date;
    deleted: boolean;
}
