'use server'

import { redirect } from "next/navigation"
import { cookies } from "next/headers"
import { SendEmail } from "@/app/lib/brevo";
import pool from "@/app/lib/db";
import { getSession } from "@/app/utils/server/auth";
import { JobApplicationStatusEnum, User, UserTypeEnum } from "@/app/types/common";
import { Job } from "../definitions";

export type JobApplyState = {
    message?: string
} | undefined

export async function jobApply(prevJobApplyState: JobApplyState, formData: FormData): Promise<JobApplyState> {
    const cookieStore = await cookies();
    const session = await getSession();

    const jobId = formData.get('jobId') as string;
    const emailContent = formData.get('emailContent') as string;

    if (session) {
        // only job seekers can apply
        if (session.user_type !== UserTypeEnum.Values.job_seeker)
            redirect('/');

        const query = `SELECT * 
            FROM user_ u
            JOIN job_seeker_ js ON u.id = js.user_id
            WHERE u.id=$1`;
        const values = [session.id];
        const user = (await pool.query<User>(query, values)).rows[0];

        const query1 = "SELECT * FROM job_ WHERE id=$1";
        const values1 = [jobId];
        const res = (await pool.query<Job>(query1, values1));
        if (res.rowCount != 1) {
            return { message: `Job with Job ID=${jobId} does not exist.` }
        }
        const job = res.rows[0];

        // check if job is already closed
        if (job.deleted) {
            return { message: `Job with Job ID=${jobId} is already closed.` }
        }

        // check if already applied to this job
        const query2 = "SELECT * FROM job_application_ WHERE user_id=$1 AND job_id=$2";
        const values2 = [session.id, jobId];
        const res2 = (await pool.query(query2, values2));
        if (res2.rowCount != 0) {
            return { message: `You already applied to this Job.` }
        }

        const query3 = "INSERT INTO job_application_ (user_id, job_id, status, date_applied) VALUES ($1, $2, $3, $4)";
        const values3 = [session.id, jobId, JobApplicationStatusEnum.Values.pending, new Date().toISOString()];
        await pool.query(query3, values3);

        await SendEmail(
            `You've applied for ${job.job_title} at ${job.company_name}`,
            emailContent, 
            `${user.firstname} ${user.lastname}`, 
            user.email);

        cookieStore.set('job_flash', 'done applied');
        redirect(`/job/application/success?job_id=${jobId}`);
    }
    else {
        redirect(`/login?applying_to=${jobId}`);
    }
}
