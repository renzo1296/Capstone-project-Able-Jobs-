'use server'

import pool from "@/app/lib/db"
import { Job } from "@/app/job/[id]/definitions"
import { getSession } from "@/app/utils/server/auth";
import { UserTypeEnum } from "@/app/types/common";

export async function deleteJobById(jobId: number): Promise<Job | null> {
    const session = await getSession();
    if (session?.user_type !== UserTypeEnum.Values.admin) {
        return null;
    }

    const client = await pool.connect();
    try {
        await client.query("BEGIN");

        await client.query(
            "UPDATE job_application_ SET status = 'closed' WHERE job_id = $1",
            [jobId]
        );

        const result = await client.query<Job>(
            "UPDATE job_ SET deleted = true WHERE id = $1 RETURNING *;",
            [jobId]
        );

        await client.query("COMMIT");
        return result.rows[0] ?? null;
    } catch (err) {
        await client.query("ROLLBACK");
        throw err;
    } finally {
        client.release();
    }
}

