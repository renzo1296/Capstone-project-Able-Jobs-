import pool from "@/app/lib/db";
import JobDetailSection, { JobInfo } from "./components/JobDetailSection";
import styles from "./page.module.css"
import ApplyBtn from "./components/ApplyBtn";
import { Job } from "./definitions";
import { getSession } from "@/app/utils/server/auth";
import { UserTypeEnum } from "@/app/types/common";
import DeleteJobBtn from "./components/DeleteJobBtn";

type JobPath = {
    id: string,
};

export default async function Page({ params }: {
        params: Promise<JobPath> })
{
    const session = await getSession();

    const { id } = (await params);
    console.log(" da job id used: ", id);

    const query = `SELECT * FROM job_ WHERE id=$1;`;
    const values = [id];

    const result = await pool.query<Job>(query, values);
    const jobDetails = result.rows[0];
    console.log("da job details dat u have is dis: ", jobDetails);


    const companyInfo: JobInfo[] = [
        { jobInfoLabel: 'Company Name:', jobInfoLabelValue: jobDetails.company_name }
    ]
    const jobDetailsInfo: JobInfo[] = [
        { jobInfoLabel: 'Job Title:', jobInfoLabelValue: jobDetails.job_title },
        { jobInfoLabel: 'Job Type:', jobInfoLabelValue: jobDetails.job_type },
        { jobInfoLabel: 'Job Details:', jobInfoLabelValue: jobDetails.job_details ?? '' },
        { jobInfoLabel: 'Monthly Salary:', jobInfoLabelValue: `PHP ${jobDetails.monthly_salary}` },
        { jobInfoLabel: 'City: ', jobInfoLabelValue: 'Quezon City' },
        { jobInfoLabel: 'Location: ', jobInfoLabelValue: jobDetails.location },
    ]
    const candidateRequirements: JobInfo[] = [
        { jobInfoLabel: 'Disabilities:', jobInfoLabelValue: jobDetails.job_title },
        { jobInfoLabel: 'Education:', jobInfoLabelValue: jobDetails.education },
    ]
    const jobListingDetails: JobInfo[] = [
        { jobInfoLabel: 'Date Posted:', jobInfoLabelValue: jobDetails.date_posted.toISOString() },
    ]

    return (
        <main>
            <h1 className={styles.job_details_header}>Job Application</h1>
            <p className={styles.job_details_header_sub}>This section lists the job details</p>
            {
                session?.user_type === UserTypeEnum.Values.admin &&
                <DeleteJobBtn jobId={id} isClosed={jobDetails.deleted} />
            }
            <JobDetailSection 
                sectionHeader={'Company Details'}
                borderColor={'#2A85E2'}
                jobInfo={companyInfo} />

            <JobDetailSection 
                sectionHeader={"Job Details"} 
                borderColor={'#11AEC0'}
                jobInfo={jobDetailsInfo} />

            <JobDetailSection 
                sectionHeader={"Candidate Requirements"} 
                borderColor={'#ED7811'}
                jobInfo={candidateRequirements} />

            <JobDetailSection 
                sectionHeader={"Job Listing Details"} 
                borderColor={'#2A85E2'}
                jobInfo={jobListingDetails} />

            {
                session?.user_type !== UserTypeEnum.Values.admin && 
                <ApplyBtn 
                    job_id={id} 
                    email_template_props={{applicant_username: session?.username ?? '', company_name: jobDetails.company_name, job_title: jobDetails.job_title}}
                    is_closed={jobDetails.deleted} />
            }
        </main>
    );

}
