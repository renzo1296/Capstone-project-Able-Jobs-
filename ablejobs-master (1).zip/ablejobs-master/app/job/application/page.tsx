import { getSession } from '@/app/utils/server/auth';
import styles from './page.module.css';
import pool from '@/app/lib/db';
import { redirect } from 'next/navigation';

interface JobApplication {
    job_title: string;
    company_name: string;
    status: string;
    date_applied: string;
}

export default async function Page() {
    const sessionPayload = await getSession();
    if (!sessionPayload) {
        redirect('/');
    }

    const query = `
        SELECT
            j.job_title,
            j.company_name,
            ja.status,
            TO_CHAR(ja.date_applied, 'YYYY-MM-DD HH24:MI:SS') as date_applied
        FROM job_application_ ja
        JOIN job_ j ON ja.job_id = j.id
        WHERE ja.user_id = $1
        ORDER BY ja.date_applied DESC
    `;
    const values = [sessionPayload?.id];
    const res = await pool.query<JobApplication>(query, values);
    const jobApplications = res.rows;

    if (res.rowCount === 0) {
        return (
            <main className={styles.application_page}>
                <h1 className={styles.h1}>Job Applications</h1>
                <p className={styles.no_applications_msg}>No applications yet...</p>
            </main>
        );
    }

    const getStatusClass = (status: string) => {
        switch(status.toLowerCase()) {
            case 'pending': return styles.status_pending;
            case 'accepted': return styles.status_accepted;
            case 'rejected': return styles.status_rejected;
            default: return '';
        }
    };

    return (
        <main className={styles.application_page}>
            <h1 className={styles.h1}>Job Applications</h1>
            <table className={styles.table}>
                <thead className={styles.thead}>
                    <tr className={styles.hdr_row}>
                        <th className={styles.hdr}>Job Title</th>
                        <th className={styles.hdr}>Company Name</th>
                        <th className={styles.hdr}>Status</th>
                        <th className={styles.hdr}>Date Applied</th>
                    </tr>
                </thead>
                <tbody className={styles.tbody}>
                    {jobApplications.map((app, index) => (
                        <tr key={index} className={styles.row}>
                            <td className={styles.cell} data-label="Job Title">
                                {app.job_title}
                            </td>
                            <td className={styles.cell} data-label="Company Name">
                                {app.company_name}
                            </td>
                            <td className={styles.cell} data-label="Status">
                                <span className={`${styles.status_badge} ${getStatusClass(app.status)}`}>
                                    {app.status}
                                </span>
                            </td>
                            <td className={styles.cell} data-label="Date Applied">
                                {app.date_applied}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </main>
    );
}

