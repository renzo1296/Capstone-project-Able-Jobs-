import { redirect } from "next/navigation"
import pool from "@/app/lib/db";
import JobFlashRenderer from "./components/JobFlashRenderer";
import { Job } from "../../[id]/definitions";
import { getSession } from "@/app/utils/server/auth";

type SearchParams = {
    job_id?: string;
};

type SuccessProps = {
    searchParams: Promise<SearchParams>
};

export default async function Page({ searchParams }: SuccessProps) {
    const params = await searchParams;
    const job_id = (typeof params.job_id === 'string') ? params.job_id : undefined 
    if (!job_id) {
        redirect('/home');
    }

    const result = await pool.query<Job>('SELECT company_name, job_title FROM job_ WHERE id=$1;', [job_id]);
    console.log('da job search result: ', result.rows);
    if (result.rowCount != 1) {
        redirect('/home');
    }
    const job_details = result.rows[0];

    // TODO: verify that you actually applied to that job
    const sessionPayload = await getSession();
    if (!sessionPayload?.id) {
        redirect('/home');
    }
    
    return (
        <JobFlashRenderer job_details={job_details} />
    )
}

