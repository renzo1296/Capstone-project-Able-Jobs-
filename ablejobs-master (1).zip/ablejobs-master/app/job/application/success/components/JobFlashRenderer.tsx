'use client'

import { useEffect, useState } from "react"
import { clearCookie } from "@/app/utils/server/cookies";
import styles from './JobFlashRenderer.module.css'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faCheckCircle } from '@fortawesome/free-solid-svg-icons'
import { Job } from "@/app/job/[id]/definitions";
import Countdown from "@/app/components/Countdown";
import NavLink from "@/app/components/NavLink";
import { getCookie } from "@/app/utils/client/cookies";

type JobFlashRendererProps = {
    job_details: Job
}

export default function JobFlashRenderer({ job_details }: JobFlashRendererProps) {
    const [showFlashState, setShowFlashState] = useState(false);
    const cookie_key = 'job_flash';
    useEffect(() => {
        const cookie = getCookie(cookie_key);
        if (!cookie) {
            window.location.replace('/');
        }
        else {
            async function deleteCookie() {
                await clearCookie(cookie_key);
            }
            deleteCookie();
            setShowFlashState(true);
        }
    }, []);

    return (
        <>
        { showFlashState &&
        <div className={styles.success_area}>
            <div className={styles.hdr1}>
                <FontAwesomeIcon className={styles.checkIcon} icon={faCheckCircle} width={25}/>
                Successfully applied!
            </div>
            <p className={styles.sub1}>
                Applied to the {job_details.job_title} position at {job_details.company_name} 
            </p>
            <p className={styles.sub1}>
                Redirecting to home in <Countdown duration={5} redirectPath={'/'} /> seconds
            </p>
            <p className={styles.sub1}>
                If you didn&apos;t automatically redirect, click <NavLink className={styles.manual_link} href='/'>here</NavLink>
            </p>
        </div>
        }
        </>
    )
}
