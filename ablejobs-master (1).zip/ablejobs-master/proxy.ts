import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/app/utils/server/auth";
import { UserTypeEnum } from "./app/types/common";

// paths that are not included in any of these arrays
// are reachable by anyone
const guestOnlyRoutes = ["/login", "/sign-up"];
const jobSeekerRoutes = ["/profile", "/job/application"];
const adminRoutes = ["/admin/dashboard", "/admin/job-seeker", "/admin/add-job", "/admin/add-disability", "/admin/add-city"];

export default async function proxy(req: NextRequest) {
    const path = req.nextUrl.pathname;
    console.log(path)

    const sessionPayload = await getSession();

    const isLoggedIn = !!sessionPayload;
    const userType = sessionPayload?.user_type;

    const isGuestOnlyRoute = guestOnlyRoutes.includes(path);
    const isJobSeekerRoute = jobSeekerRoutes.includes(path);
    const isAdminRoute = adminRoutes.includes(path);

   // Guest-only routes
    if (isGuestOnlyRoute && isLoggedIn) {
        if (userType === UserTypeEnum.Values.admin) {
            return NextResponse.redirect(new URL("/admin/dashboard", req.nextUrl));
        } else {
            return NextResponse.redirect(new URL("/profile", req.nextUrl));
        }
    }

    // Job seeker protected routes
    if (isJobSeekerRoute) {
        if (!isLoggedIn || userType !== UserTypeEnum.Values.job_seeker) {
            return NextResponse.redirect(new URL("/", req.nextUrl));
        }
    }

    // Admin-only routes
    if (isAdminRoute) {
        if (!isLoggedIn || userType !== UserTypeEnum.Values.admin) {
            return NextResponse.redirect(new URL("/", req.nextUrl));
        }
    } 

    return NextResponse.next();
}

